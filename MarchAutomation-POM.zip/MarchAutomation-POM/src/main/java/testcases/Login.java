package testcases;


import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class Login extends BaseClass {
	
	
	
	@Test
	public void runLogin() {
		LoginPage lp=new LoginPage();
	lp.enterUsername()
		.enterPassword()
	    .clickLoginButton().clickToggleMenu().clickViewAll().clickOnSales().clickOnLeads().clickOnNewButton()
	    .selectSalutation().enterLasrname().enterCompanyName().clickOnSave().verifyingLeadNameAndCompanyName().clickOnEmailWidget()
	    .clickOnAddEmailToDoList().selectTheDueDate().selectTheStatus().saveTheToDoList().clickOnEmailButton().enterEmailAddress().enterEmailBody()
	    .clickOnSend().clickOnShowMoreActions().clickChangeStatus().changeStausOptions().selectCompletedStatus().clickOnSaveButton().clickOnDetails()
	    .clickEditLeadStatus().scrollToEditLeadStatus().clickOnLeadstatusOptions().selectTheLeadStatus().saveTheStatusChange().scrollToMarkStatus()
	    .verifyingLeadStatusAndUpdate().clickShowMoreActions().clickOnConvertOption().clickOnConvertButton().clickOnGoToLeadsButton().verifyTheLeadConversion()
	    .clickOnOpportunityTab().enterTheOpportunityNameAndSearch().selectTheOpportunity().clickOnProductWidget().selectPriceBook().clickOnPriceBookOptions()
	    .selectStandardOption().clickOnSavePriceBook().clickOnProductWidget1().selectAddProducts().enterSlaAndSearch().clickOnSlaProducts().selectAllProducts()
	    .clickOnNext().editTheSelectedProducts().clickOnSaveProducts().addAttachemnt().clickOnNewEventWidget().clickOnViewCalendar().windowsHandling()
	    .clickOnNewEvent().clickOnSubject().selectSubject().enterTheStartAndEndDate().enterMeetingDescription().clickOnSaveMeeting().closeTheCalendar();	   
	
	}
}
