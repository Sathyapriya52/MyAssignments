package pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import base.BaseClass;

public class NewlyCreatedLeadPage extends BaseClass {
	
	public NewlyCreatedLeadPage verifyingLeadNameAndCompanyName() {
		String actulaLeadName = driver.findElement(By.xpath("//slot[@name='primaryField']/lightning-formatted-name")).getText();		
		String expectedLeadName="Ms. "+lastName;
		Assert.assertEquals(actulaLeadName, expectedLeadName);	
		String actualCompanyName = driver.findElement(By.xpath("//p[@title='Company']/following::lightning-formatted-text")).getText();			
		String expectedCompanyName=companyName;
		Assert.assertEquals(actualCompanyName, expectedCompanyName);
		return this;
	}
	public NewlyCreatedLeadPage clickOnEmailWidget() {
		try {
			WebElement emailWidget = driver.findElement(By.xpath("//button[@title='Email']/following::button"));
			emailWidget.click();
		} catch (Exception e1) {
			WebElement emailWidget = driver.findElement(By.xpath("//button[@title='Email']/following::button"));
			driver.executeScript("arguments[0].click()", emailWidget);
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage clickOnAddEmailToDoList() {
		driver.findElement(By.xpath("//span[text()='Add Email to To Do List']")).click();
		return this;
	}
	public NewlyCreatedLeadPage selectTheSubject() {
		driver.findElement(By.xpath("(//label[text()='Subject']/following::div)[1]")).click();
		driver.findElement(By.xpath("(//span[text()='Email']/parent::span)[2]")).click();
		return this;
	}
	public NewlyCreatedLeadPage selectTheDueDate() {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Due Date']")));
			driver.findElement(By.xpath("//label[text()='Due Date']")).click();
		} catch (Exception e) {
			WebElement date = driver.findElement(By.xpath("//label[text()='Due Date']"));
			driver.executeScript("arguments[0].click()", date);
		}
		//Get Today's date
				LocalDate currentDate=LocalDate.now();
				System.out.println("Today date is: "+currentDate);
				DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");	
				String date = currentDate.format(format);
				System.out.println(date);
				WebElement dueDate = driver.findElement(By.xpath("//span[text()='Due Date']/following::input"));
				dueDate.sendKeys(date,Keys.ENTER);		
		return this;
	}
	
	public NewlyCreatedLeadPage selectTheStatus() {
		driver.findElement(By.xpath("//a[@class='select']")).click();		 
		driver.findElement(By.xpath("//a[@title='In Progress']")).click();		
		return this;
	}
	public NewlyCreatedLeadPage saveTheToDoList() {
		driver.findElement(By.xpath("//button[contains(@class,'ShareButton uiButton')]")).click();
		return this;
	}
	public NewlyCreatedLeadPage clickOnEmailButton() {
		try {
			driver.findElement(By.xpath("//span[@value='SendEmail']")).click();
		} catch (Exception e) {
			WebElement email = driver.findElement(By.xpath("//span[@value='SendEmail']"));
			driver.executeScript("arguments[0].click()", email);
		}
		return this;
	}
	public NewlyCreatedLeadPage enterEmailAddress() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")));
		String company=companyName.replaceAll("[^a-zA-Z]", " ");
		String finalCompanyName = company.replaceAll(" ","");
		System.out.println("Company name is: "+finalCompanyName);
		driver.findElement(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")).sendKeys(lastName+"@"+finalCompanyName+".com");
		driver.findElement(By.xpath("//input[@placeholder='Enter Subject...']")).sendKeys("New Lead");
		return this;
	}
	public NewlyCreatedLeadPage enterEmailBody() {
		WebElement iframe = driver.findElement(By.xpath("//iframe[@title='CK Editor Container']"));
		driver.switchTo().frame(iframe);
		//Switch to child frame
		WebElement iframe1 = driver.findElement(By.xpath("//iframe[@title='Email Body']"));
		driver.switchTo().frame(iframe1);
		driver.findElement(By.xpath("//body[@contenteditable='true']")).clear();
		driver.findElement(By.xpath("//body[@contenteditable='true']")).sendKeys("This email is a test email");
		driver.switchTo().defaultContent();
		return this;
	}
	public NewlyCreatedLeadPage clickOnSend() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'send uiButton')]")));
		driver.findElement(By.xpath("//button[contains(@class,'send uiButton')]")).click();
		return this;
	}
	public NewlyCreatedLeadPage clickOnShowMoreActions() {
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage sld')]")));		
		try {
			WebElement action = driver.findElement(By.xpath("//a[contains(@class,'rowActionsPlaceHolder')]//span[text()='Show more actions']"));
			action.click();
		} catch (Exception e1) {
			WebElement action = driver.findElement(By.xpath("//a[contains(@class,'rowActionsPlaceHolder')]//span[text()='Show more actions']"));
			driver.executeScript("arguments[0].click()", action);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage clickChangeStatus() {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")));
			driver.findElement(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")).click();
		} catch (Exception e2) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")));
			WebElement changeStatus = driver.findElement(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div"));
			driver.executeScript("arguments[0].click()", changeStatus);
		}
		return this;
	}
	public NewlyCreatedLeadPage changeStausOptions() {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='select']")));
			driver.findElement(By.xpath("//a[@class='select']")).click();				
		} catch(ElementClickInterceptedException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select);
		}catch(ElementNotInteractableException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage selectCompletedStatus() {
		driver.findElement(By.xpath("//a[@title='Completed']")).click();
		return this;
	}
	
	public NewlyCreatedLeadPage clickOnSaveButton() {
		driver.findElement(By.xpath("//button[contains(@class,'undefined uiButton')]/span")).click();
		return this;
	}
	
	public NewlyCreatedLeadPage clickOnDetails() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
		WebElement details = driver.findElement(By.xpath("//li[@title='Details']"));		
		try {
			details.click();
		} catch (Exception e2) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
			WebElement details1 = driver.findElement(By.xpath("//li[@title='Details']"));	
			driver.executeScript("arguments[0].click", details1);
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage clickEditLeadStatus() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Edit Lead Status']")));
			driver.findElement(By.xpath("//button[@title='Edit Lead Status']")).click();
		} catch (Exception e3) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
			WebElement details1 = driver.findElement(By.xpath("//li[@title='Details']"));		
			try {
				details1.click();
			} catch (Exception e2) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
				WebElement details2 = driver.findElement(By.xpath("//li[@title='Details']"));	
				driver.executeScript("arguments[0].click", details2);
			}		
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage scrollToEditLeadStatus() {
		try {
			WebElement scroll = driver.findElement(By.xpath("//label[text()='Rating']"));
			Actions obj=new Actions(driver);
			obj.scrollToElement(scroll).perform();
		} catch (NoSuchElementException e3) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Edit Lead Status']")));
			driver.findElement(By.xpath("//button[@title='Edit Lead Status']")).click();
			WebElement scroll  = driver.findElement(By.xpath("//label[text()='Rating']"));
			Actions obj=new Actions(driver);
			obj.scrollToElement(scroll).perform();
		}
			
		return this;
	}
	public NewlyCreatedLeadPage clickOnLeadstatusOptions() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")).click();
		} catch (ElementClickInterceptedException e) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
		} catch (ElementNotInteractableException e) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
		}		
		return this;
	}
	public NewlyCreatedLeadPage selectTheLeadStatus() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
			WebElement status = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
			status.click();
		} catch (ElementClickInterceptedException e1) {
			WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));	
			driver.executeScript("arguments[0].click()", status1);
		} catch (ElementNotInteractableException e1) {
			WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));	
			driver.executeScript("arguments[0].click()", status1);
		} catch (TimeoutException e) {
			WebElement scroll  = driver.findElement(By.xpath("//label[text()='Rating']"));
			Actions obj=new Actions(driver);			
			obj.scrollToElement(scroll).perform();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
			WebElement status = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
			status.click();
		}
		return this;
	}
	public NewlyCreatedLeadPage saveTheStatusChange() {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		return this;
	}
	
	public NewlyCreatedLeadPage scrollToMarkStatus() {
		WebElement scroll1 = driver.findElement(By.xpath("//span[text()='Mark Status as Complete']"));
		Actions obj=new Actions(driver);
		obj.moveToElement(scroll1).perform();
		return this;
	}
	
	public NewlyCreatedLeadPage verifyingLeadStatusAndUpdate() {
		String stageStatus = driver.findElement(By.xpath("//a[@title='Working - Contacted']/span[@class='title slds-path__title']")).getText();
		System.out.println("status of working contacted: "+stageStatus);
		if(stageStatus.contains("stage complete")) {
			System.out.println("Working - Contacted stage is marked as completed");
		}else {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
				driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]")).click();
			} catch (Exception e) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
				WebElement markStatus = driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]"));
				driver.executeScript("arguments[0].click()", markStatus);
			}
		}
		return this;
		}
	
	public NewlyCreatedLeadPage clickShowMoreActions() {
		try {
			driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		} catch (ElementNotInteractableException e) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		}
		return this;
	}

public NewlyCreatedLeadPage clickOnConvertOption() {
	try {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
		driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
	} catch (ElementClickInterceptedException e) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
		WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
		driver.executeScript("arguments[0].click()", dropDown2);
	} catch (ElementNotInteractableException e) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
		WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
		driver.executeScript("arguments[0].click()", dropDown2);
	} catch (StaleElementReferenceException e) {
		driver.get(driver.getCurrentUrl());
		driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
		} catch (ElementClickInterceptedException e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		}
	}

		return this;
	}

public NewlyCreatedLeadPage clickOnConvertButton() {
	try {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
		driver.findElement(By.xpath("//button[text()='Convert']")).click();			
	} catch (Exception e) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
		WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
		driver.executeScript("arguments[0].click()", convert1);
	}
	return this;
}

public RecentlyViewedLeadsPage clickOnGoToLeadsButton() {
	try {
		driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
	} catch (NoSuchElementException e) {
		driver.get(driver.getCurrentUrl());
		try {
			driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
		} catch (Exception e1) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		} 
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
		} catch (ElementClickInterceptedException e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (ElementNotInteractableException e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} 
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			driver.findElement(By.xpath("//button[text()='Convert']")).click();			
		} catch (Exception e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
			driver.executeScript("arguments[0].click()", convert1);
		}
		try {
			driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
		} catch (Exception e1) {
			driver.get(driver.getCurrentUrl());
			try {
				driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			} catch (Exception e2) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			} 
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
			} catch (ElementClickInterceptedException e2) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} catch (ElementNotInteractableException e2) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} 
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				driver.findElement(By.xpath("//button[text()='Convert']")).click();			
			} catch (Exception e2) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
				driver.executeScript("arguments[0].click()", convert1);
			}
			driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
		}
	}
	return new RecentlyViewedLeadsPage();
}
	
}

			

