package pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.BaseClass;

public class CalendarPage extends BaseClass {
	
	public CalendarPage windowsHandling() {
		Set<String> windows = driver.getWindowHandles();
	       List<String> windowsList=new ArrayList<String>(windows);
	       driver.switchTo().window(windowsList.get(1));
	       String title = driver.getTitle();
	       System.out.println("Title of page: "+title); 		
		return this;
	}

	public CalendarPage clickOnNewEvent() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'new-event-button')]")));
	       driver.findElement(By.xpath("//button[contains(@class,'new-event-button')]")).click();
		return this;
	}
	
	public CalendarPage clickOnSubject() {
		driver.findElement(By.xpath("//label[text()='Subject']/following-sibling::div")).click();
		return this;
	}
	
	public CalendarPage selectSubject() {
		driver.findElement(By.xpath("//span[@title='Meeting']")).click();
		return this;
	}
	
	public CalendarPage enterTheStartAndEndDate() {
		LocalDate currentDate=LocalDate.now();
		LocalDate dayAfterTom=currentDate.plusDays(2);
	       System.out.println("Day after tomo is: "+dayAfterTom);
	       DateTimeFormatter format1=DateTimeFormatter.ofPattern("dd-MMM-yyyy");		
	       String dayAfterTomformatted = dayAfterTom.format(format1);      
	       System.out.println("Formatted date: "+dayAfterTomformatted);
	       WebElement startDate = driver.findElement(By.xpath("//legend[text()='Start']/following::input"));
	       startDate.clear();
	       startDate.sendKeys(dayAfterTomformatted,Keys.ENTER);
	       WebElement endDate = driver.findElement(By.xpath("//legend[text()='End']/following::input"));
	       endDate.clear();
	       endDate.sendKeys(dayAfterTomformatted,Keys.ENTER);
		return this;
	}
	
	public CalendarPage enterMeetingDescription() {
		Actions obj=new Actions(driver);
		obj.scrollToElement(driver.findElement(By.xpath("//span[text()='Description']"))).perform();
	       driver.findElement(By.xpath("//span[text()='Description']/following::textarea")).sendKeys("Discussion about the product"+Keys.ENTER);
		return this;
	}
	
	public CalendarPage clickOnSaveMeeting() {
		driver.findElement(By.xpath("//button[@title='Save']")).click();
		return this;
	}
	
	public CalendarPage closeTheCalendar() {
		driver.close();
		return this;
	}
	
}



