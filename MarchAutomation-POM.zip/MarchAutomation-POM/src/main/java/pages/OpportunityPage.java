package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.BaseClass;

public class OpportunityPage extends BaseClass {

	public OpportunityPage clickOnProductWidget() {
		WebElement showProduct = driver.findElement(By.xpath("//span[text()='Show actions for Products']"));
		driver.executeScript("arguments[0].click()", showProduct);
		return this;
	}

	public OpportunityPage selectPriceBook() {
		driver.findElement(By.xpath("//a[@title='Choose Price Book']")).click();
		return this;
	}

	public OpportunityPage clickOnPriceBookOptions() {
		driver.findElement(By.xpath("//a[@class='select']")).click();
		return this;
	}

	public OpportunityPage selectStandardOption() {
		WebElement priceBook = driver.findElement(By.xpath("//a[text()='Standard']"));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a[text()='Standard']")));
		try {
			priceBook.click();
		} catch (ElementClickInterceptedException e) {
			driver.executeScript("arguments[0].click()", priceBook);
		}catch (ElementNotInteractableException e) {
			driver.executeScript("arguments[0].click()", priceBook);
		}
		return this;
	}

	public OpportunityPage clickOnSavePriceBook() {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		return this;
	}


	public OpportunityPage clickOnProductWidget1() {
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a")));
			WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));			
			showProduct1.click();
		} catch (ElementClickInterceptedException e) {
			WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));
			driver.executeScript("arguments[0].click()", showProduct1);	
		}
		return this;
	}

	public OpportunityPage selectAddProducts() {
		driver.findElement(By.xpath("//a[@title='Add Products']")).click();
		return this;
	}

	public OpportunityPage enterSlaAndSearch() {
		WebElement sla = driver.findElement(By.xpath("//input[@title='Search Products']"));
		sla.click();
		sla.sendKeys("SLA"+Keys.ENTER);
		return this;
	}

	public OpportunityPage clickOnSlaProducts() {
		try {
			//driver.findElement(By.xpath("(//div[@data-aura-class='forceSearchInputLookupDesktopActionItem'])[1]")).click();
			driver.findElement(By.xpath("//span[text()='Search Products']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
			driver.executeScript("arguments[0].click()", sla1);
		}catch (ElementNotInteractableException e) {
			WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
			driver.executeScript("arguments[0].click()", sla1);
		}
		return this;
	}

	public OpportunityPage selectAllProducts() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select 4 items']")));
		WebElement select = driver.findElement(By.xpath("//span[text()='Select 4 items']"));
		try {
			select.click();
		} catch (ElementClickInterceptedException e) {
			driver.executeScript("arguments[0].click()", select);
		}
		return this;
	}

	public OpportunityPage clickOnNext() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Next']")));
		driver.findElement(By.xpath("//span[text()='Next']")).click();	
		return this;
	}

	public OpportunityPage editTheSelectedProducts() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Edit Selected Products']")));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr/td[2]")));

		try {
			WebElement product = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));	
			product.click();
		} catch (Exception e1) {
			WebElement product = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));	
			driver.executeScript("arguments[0].click()", product);
		}

		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr/td[2]//input[@type='text']")).sendKeys("2"+Keys.ENTER);
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[2]/td[2]")).click();
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[2]/td[2]//input")).sendKeys("10"+Keys.ENTER);
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[3]/td[2]")).click();		
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[3]/td[2]//input")).sendKeys("1"+Keys.ENTER);
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[4]/td[2]")).click();
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[4]/td[2]//input")).sendKeys("5"+Keys.ENTER);
		return this;
	}

	public OpportunityPage clickOnSaveProducts() {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Save']")));
		} catch (Exception e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Save']")));
		}
		WebElement save = driver.findElement(By.xpath("//button[@title='Save']"));
		save.click();
		return this;
	}

	public OpportunityPage addAttachemnt() {
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage')]")));
		WebElement upload = driver.findElement(By.xpath("//input[@type='file']"));
		upload.sendKeys("C:\\Users\\sathy\\OneDrive\\Desktop\\Screenshot 2024-01-20 181042.png");
		try {			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Done']/parent::button")));
			driver.findElement(By.xpath("//span[text()='Done']/parent::button")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement done = driver.findElement(By.xpath("//span[text()='Done']/parent::button"));
			driver.executeScript("arguments[0].click()", done);
		}catch (ElementNotInteractableException e) {
			WebElement done = driver.findElement(By.xpath("//span[text()='Done']/parent::button"));
			driver.executeScript("arguments[0].click()", done);
		}
		return this;
	}

	public OpportunityPage clickOnNewEventWidget() {
		try {
			driver.findElement(By.xpath("(//span[@value='NewEvent'])[2]/following::button[@title='More Actions']")).click();
		} catch (Exception e) {
			WebElement newEvent = driver.findElement(By.xpath("(//span[@value='NewEvent'])[2]/following::button[@title='More Actions']"));
			driver.executeScript("arguments[0].click()", newEvent);
		}
		return this;
	}
	
	public CalendarPage clickOnViewCalendar() {
		try {
			driver.findElement(By.xpath("//span[text()='View Calendar']")).click();
		} catch (Exception e) {
			WebElement viewCalendar = driver.findElement(By.xpath("//span[text()='View Calendar']"));
			driver.executeScript("arguments[0].click()", viewCalendar);
		}
		return new CalendarPage();
	}	
	
}
