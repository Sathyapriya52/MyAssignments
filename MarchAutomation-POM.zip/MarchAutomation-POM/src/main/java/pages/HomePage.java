package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseClass;

public class HomePage extends BaseClass {

	public HomePage clickToggleMenu() {
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		return this;
	}
	
public HomePage clickViewAll() {
	wait=new WebDriverWait(driver, Duration.ofSeconds(30));
	try {
		driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
	} catch (NoSuchElementException e2) {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='slds-icon-waffle']")));
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
	} catch (StaleElementReferenceException e2) {
		driver.get(driver.getCurrentUrl());
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
	}
	return this;
		
	}

public SalesforceHomePage clickOnSales() {
	try {
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
	} catch (ElementClickInterceptedException e) {
		WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
		driver.executeScript("arguments[0].click()", sales);			
	}catch (ElementNotInteractableException e) {
		WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
		driver.executeScript("arguments[0].click()", sales);			
	}catch (NoSuchElementException e1) {
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='slds-icon-waffle']")));
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
		viewAll.click();
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
	}
	return new SalesforceHomePage();
}




}
