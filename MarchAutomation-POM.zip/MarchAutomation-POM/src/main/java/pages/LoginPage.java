package pages;


import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.BaseClass;

public class LoginPage extends BaseClass {

	
	public LoginPage enterUsername() {
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		return this;
	}

	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		return this;
	}

	public HomePage clickLoginButton() {
		driver.findElement(By.id("Login")).click();	
		return  new HomePage();
	}

}


