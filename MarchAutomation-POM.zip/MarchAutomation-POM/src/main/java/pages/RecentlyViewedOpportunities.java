package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.BaseClass;

public class RecentlyViewedOpportunities extends BaseClass{

	public RecentlyViewedOpportunities enterTheOpportunityNameAndSearch() {
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@name='Opportunity-search-input']")));
		driver.findElement(By.xpath("//input[@name='Opportunity-search-input']")).sendKeys(companyName+Keys.ENTER);	
		return this;
	}
	
	public OpportunityPage selectTheOpportunity() {
		try {
			driver.findElement(By.xpath("//a[@title='"+companyName+"-']")).click();
		} catch (StaleElementReferenceException e1) {			
			driver.findElement(By.xpath("//a[@title='"+companyName+"-']")).click();
		}catch (ElementClickInterceptedException e1) {			
			WebElement record = driver.findElement(By.xpath("//a[@title='"+companyName+"-']"));
			driver.executeScript("arguments[0].click()", record);
		}catch (ElementNotInteractableException e1) {			
			WebElement record = driver.findElement(By.xpath("//a[@title='"+companyName+"-']"));
			driver.executeScript("arguments[0].click()", record);
		}
	
		return new OpportunityPage();
	}
	
}

		