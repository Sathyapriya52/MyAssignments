package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.github.javafaker.Faker;

import base.BaseClass;

public class RecentlyViewedLeadsPage extends BaseClass{
	
	Faker fake=new Faker();
	
	public RecentlyViewedLeadsPage clickOnNewButton() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='New']")));
		driver.findElement(By.xpath("//div[text()='New']")).click();
		return this;
	}

	public RecentlyViewedLeadsPage selectSalutation() {
		driver.findElement(By.xpath("(//div[@class='slds-combobox_container'])[2]")).click();
		driver.findElement(By.xpath("//span[@title='Ms.']")).click();
		return this;
	}
	public RecentlyViewedLeadsPage enterLasrname() {
		
		lastName = fake.name().lastName();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='lastName']")));
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		return this;
	}
public RecentlyViewedLeadsPage enterCompanyName() {
	companyName = fake.company().name();
	driver.findElement(By.xpath("//input[@name='Company']")).sendKeys(companyName);
	return this;
	}
public NewlyCreatedLeadPage clickOnSave() {
	
	driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
	return new NewlyCreatedLeadPage();
}
public RecentlyViewedLeadsPage verifyTheLeadConversion() {
	//Verify that the lead is removed from the lead list.	
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+ Keys.ENTER);	
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")));
		} catch (Exception e) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
			driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+ Keys.ENTER);	
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")));
		}
		String leadVerification = driver.findElement(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")).getText();
		System.out.println("LeadVerification: "+leadVerification);
		if(leadVerification.contains("No items to display.")) {
			System.out.println("The lead is removed from the lead list");
		}else {
			System.out.println("The lead is not removed from the lead list");  
		}
	return this;
	} 

public RecentlyViewedOpportunities clickOnOpportunityTab() {
	WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
	driver.executeScript("arguments[0].click()", opp);	
	return new RecentlyViewedOpportunities();
}
}


	
		
		
	
					
		

