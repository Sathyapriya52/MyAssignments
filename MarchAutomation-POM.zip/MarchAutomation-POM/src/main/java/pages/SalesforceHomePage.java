package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.BaseClass;

public class SalesforceHomePage extends BaseClass{
	
	public RecentlyViewedLeadsPage clickOnLeads() {
		try {
			driver.findElement(By.xpath("(//span[text()='Leads'])[1]")).click();
		} catch (Exception e) {
			WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));			
			driver.executeScript("arguments[0].click()", leadsTab);
		}
		return new RecentlyViewedLeadsPage();
	}

}
