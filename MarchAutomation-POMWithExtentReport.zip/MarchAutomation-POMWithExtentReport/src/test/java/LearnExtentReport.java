import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {
	
	public static void main(String[] args) {
		
		
		//Setup the report path
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reprot/result.html");
		
		//Save the history
		
		reporter.setAppendExisting(true);
		
		//Create an object
		ExtentReports extent=new ExtentReports();
		
		//Attach the data with report
		extent.attachReporter(reporter);
		
		//
	}

}
