package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.github.javafaker.Faker;

import base.BaseClass;

public class RecentlyViewedLeadsPage extends BaseClass{
	
	Faker fake=new Faker();
	
	public RecentlyViewedLeadsPage clickOnNewButton() throws IOException {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='New']")));
			driver.findElement(By.xpath("//div[text()='New']")).click();
			reportStep("Successfuly clicked new button","pass");
		} catch (Exception e) {
			reportStep("Failed to click new button","fail"+e);
		}
		return this;
	}

	public RecentlyViewedLeadsPage selectSalutation() throws IOException {
		try {
			driver.findElement(By.xpath("(//div[@class='slds-combobox_container'])[2]")).click();
			driver.findElement(By.xpath("//span[@title='Ms.']")).click();
			reportStep("Successfuly selected the salutation","pass");
		} catch (Exception e) {
			reportStep("Failed to select the salutation","fail"+e);
		}
		return this;
	}
	public RecentlyViewedLeadsPage enterLasrname() throws IOException {
		
		try {
			lastName = fake.name().lastName();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='lastName']")));
			driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
			reportStep("Successfuly enter the lastname","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the lastname","fail"+e);
		}
		return this;
	}
public RecentlyViewedLeadsPage enterCompanyName() throws IOException {
	try {
		companyName = fake.company().name();
		driver.findElement(By.xpath("//input[@name='Company']")).sendKeys(companyName);
		reportStep("Successfuly entered the company name","pass");
	} catch (Exception e) {
		reportStep("Failed to enter the company name","fail"+e);
	}
	return this;
	}
public NewlyCreatedLeadPage clickOnSave() throws IOException {
	
	try {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		reportStep("Successfuly clicked on Save button","pass");
	} catch (Exception e) {
		reportStep("Failed to click save button","fail"+e);
	}
	return new NewlyCreatedLeadPage();
}
public RecentlyViewedLeadsPage verifyTheLeadConversion() throws IOException {
	//Verify that the lead is removed from the lead list.	
		try {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
			driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+ Keys.ENTER);
			reportStep("Successfuly entered the lead name in search field","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the lead name in search field","fail"+e);
		}	
		try {
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")));
			} catch (Exception e) {
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
				driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+ Keys.ENTER);	
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")));
			}
			reportStep("Successfuly validated the Lead convertion","pass");
		} catch (Exception e) {
			reportStep("Failed to validate the lead convertion","fail"+e);
		}
		String leadVerification = driver.findElement(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")).getText();
		System.out.println("LeadVerification: "+leadVerification);
		if(leadVerification.contains("No items to display.")) {
			System.out.println("The lead is removed from the lead list");
		}else {
			System.out.println("The lead is not removed from the lead list");  
		}
	return this;
	} 

public RecentlyViewedOpportunities clickOnOpportunityTab() throws IOException {
	try {
		WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
		driver.executeScript("arguments[0].click()", opp);
		reportStep("Successfuly clicked Opportunity tab","pass");
	} catch (Exception e) {
		reportStep("Failed to click Opportunity tab","fail"+e);
	}	
	return new RecentlyViewedOpportunities();
}
}


	
		
		
	
					
		

