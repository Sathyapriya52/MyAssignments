package pages;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import base.BaseClass;

public class NewlyCreatedLeadPage extends BaseClass {
	
	public NewlyCreatedLeadPage verifyingLeadNameAndCompanyName() throws IOException {
		try {
			String actulaLeadName = driver.findElement(By.xpath("//slot[@name='primaryField']/lightning-formatted-name")).getText();		
			String expectedLeadName="Ms. "+lastName;
			Assert.assertEquals(actulaLeadName, expectedLeadName);	
			String actualCompanyName = driver.findElement(By.xpath("//p[@title='Company']/following::lightning-formatted-text")).getText();			
			String expectedCompanyName=companyName;
			Assert.assertEquals(actualCompanyName, expectedCompanyName);
			reportStep("Successfuly verified the leadname and company name","pass");
		} catch (Exception e) {
			reportStep("Failed to verify the leadname and company name","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage clickOnEmailWidget() throws IOException {
		try {
			try {
				WebElement emailWidget = driver.findElement(By.xpath("//button[@title='Email']/following::button"));
				emailWidget.click();
			} catch (Exception e1) {
				WebElement emailWidget = driver.findElement(By.xpath("//button[@title='Email']/following::button"));
				driver.executeScript("arguments[0].click()", emailWidget);
			}
			reportStep("Successfuly clicked email widget","pass");
		} catch (Exception e) {
			reportStep("Failed to click email widget","fail"+e);
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage clickOnAddEmailToDoList() throws IOException {
		try {
			driver.findElement(By.xpath("//span[text()='Add Email to To Do List']")).click();
			reportStep("Successfuly clicked add email to do list","pass");
		} catch (Exception e) {
			reportStep("Failed to click add email to do list","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage selectTheSubject() throws IOException {
		try {
			driver.findElement(By.xpath("(//label[text()='Subject']/following::div)[1]")).click();
			reportStep("Successfuly clicked subject","pass");
		} catch (Exception e) {
			reportStep("Failed to click subject","fail"+e);	
		}
		return this;
	}
		
		public NewlyCreatedLeadPage selectEmailAsSubject() throws IOException {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Email']/parent::span)[2]")));
				driver.findElement(By.xpath("(//span[text()='Email']/parent::span)[2]")).click();
				reportStep("Successfuly selected email as subject","pass");
			} catch (Exception e) {
				reportStep("Failed to select email as subject","fail"+e);	
			}
		
		return this;
	}
		
	public NewlyCreatedLeadPage clickTheDueDate() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Due Date']")));
				driver.findElement(By.xpath("//label[text()='Due Date']")).click();
			} catch (Exception e) {
				WebElement date = driver.findElement(By.xpath("//label[text()='Due Date']"));
				driver.executeScript("arguments[0].click()", date);
			}
			reportStep("Successfuly clicked the due date","pass");
		} catch (Exception e) {
			reportStep("Failed to click the due date","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage selectTheDueDate() throws IOException {	
		//Get Today's date
				try {
					LocalDate currentDate=LocalDate.now();
					System.out.println("Today date is: "+currentDate);
					DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");	
					String date = currentDate.format(format);
					System.out.println(date);
					WebElement dueDate = driver.findElement(By.xpath("//span[text()='Due Date']/following::input"));
					dueDate.sendKeys(date,Keys.ENTER);
					reportStep("Successfuly enter the due date","pass");
				} catch (Exception e) {
					reportStep("Failed to enter the due date","fail"+e);
				}		
		return this;
	}
	
	public NewlyCreatedLeadPage clickTheStatusOption() throws IOException {
		try {
			driver.findElement(By.xpath("//a[@class='select']")).click();
			reportStep("Successfuly clicked the status option","pass");
		} catch (Exception e) {
			reportStep("Failed to click the status option","fail"+e);
		}				
		return this;
	}
	
	public NewlyCreatedLeadPage selectTheInprogressStatus() throws IOException {			 
		try {
			driver.findElement(By.xpath("//a[@title='In Progress']")).click();
			reportStep("Successfuly selected the inprogress status","pass");
		} catch (Exception e) {
			reportStep("Failed to select the status","fail"+e);
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage saveTheToDoList() throws IOException {
		try {
			driver.findElement(By.xpath("//button[contains(@class,'ShareButton uiButton')]")).click();
			reportStep("Successfuly saved the to do list","pass");
		} catch (Exception e) {
			reportStep("Failed to save the to do list","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage clickOnEmailButton() throws IOException {
		try {
			try {
				driver.findElement(By.xpath("//span[@value='SendEmail']")).click();
			} catch (Exception e) {
				WebElement email = driver.findElement(By.xpath("//span[@value='SendEmail']"));
				driver.executeScript("arguments[0].click()", email);
			}
			reportStep("Successfuly clicked the email button","pass");
		} catch (Exception e) {
			reportStep("Failed to click the email button","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage enterEmailAddress() throws IOException {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")));
			String company=companyName.replaceAll("[^a-zA-Z]", " ");
			String finalCompanyName = company.replaceAll(" ","");
			System.out.println("Company name is: "+finalCompanyName);
			driver.findElement(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")).sendKeys(lastName+"@"+finalCompanyName+".com");
			reportStep("Successfuly entered the email address","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the email address","fail"+e);
		}
		return this;
	}
	
	
	public NewlyCreatedLeadPage enterTheMailSubject() throws IOException {
		try {
			driver.findElement(By.xpath("//input[@placeholder='Enter Subject...']")).sendKeys("New Lead");
			reportStep("Successfuly entered the email subject","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the email subject","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage enterEmailBody() throws IOException {
		try {
			WebElement iframe = driver.findElement(By.xpath("//iframe[@title='CK Editor Container']"));
			driver.switchTo().frame(iframe);
			reportStep("Successfuly switched to frame","pass");
		} catch (Exception e) {
			reportStep("Failed to switch the frame","fail"+e);
		}
		//Switch to child frame
		try {
			WebElement iframe1 = driver.findElement(By.xpath("//iframe[@title='Email Body']"));
			driver.switchTo().frame(iframe1);
			reportStep("Successfuly switched to inner frame","pass");
		} catch (Exception e) {
			reportStep("Failed to switch to the inner frame","fail"+e);
		}
		try {
			driver.findElement(By.xpath("//body[@contenteditable='true']")).clear();
			driver.findElement(By.xpath("//body[@contenteditable='true']")).sendKeys("This email is a test email");
			reportStep("Successfuly entered the email body","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the email body","fail"+e);
		}
		try {
			driver.switchTo().defaultContent();
			reportStep("Successfuly switched to the default content","pass");
		} catch (Exception e) {
			reportStep("Failed to switch to the default content","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage clickOnSend() throws IOException {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'send uiButton')]")));
			driver.findElement(By.xpath("//button[contains(@class,'send uiButton')]")).click();
			reportStep("Successfuly clicked the send button","pass");
		} catch (Exception e) {
			reportStep("Failed to click the send button","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage clickOnShowMoreActions() throws IOException {
		try {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage sld')]")));		
			try {
				WebElement action = driver.findElement(By.xpath("//a[contains(@class,'rowActionsPlaceHolder')]//span[text()='Show more actions']"));
				action.click();
			} catch (Exception e1) {
				WebElement action = driver.findElement(By.xpath("//a[contains(@class,'rowActionsPlaceHolder')]//span[text()='Show more actions']"));
				driver.executeScript("arguments[0].click()", action);
			}
			reportStep("Successfuly clicked show more actions","pass");
		} catch (Exception e) {
			reportStep("Failed to click show more actions","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage clickChangeStatus() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")));
				driver.findElement(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")).click();
			} catch (Exception e2) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")));
				WebElement changeStatus = driver.findElement(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div"));
				driver.executeScript("arguments[0].click()", changeStatus);
			}
			reportStep("Successfuly clicked change status","pass");
		} catch (Exception e) {
			reportStep("Failed to click change status","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage changeStausOptions() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='select']")));
				driver.findElement(By.xpath("//a[@class='select']")).click();				
			} catch(ElementClickInterceptedException e) {
				WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
				driver.executeScript("arguments[0].click()", select);
			}catch(ElementNotInteractableException e) {
				WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
				driver.executeScript("arguments[0].click()", select);
			}
			reportStep("Successfuly clicked change status options","pass");
		} catch (Exception e) {
			reportStep("Failed to click change status option","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage selectCompletedStatus() throws IOException {
		try {
			driver.findElement(By.xpath("//a[@title='Completed']")).click();
			reportStep("Successfuly selected completed status","pass");
		} catch (Exception e) {
			reportStep("Failed to select the status","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage clickOnSaveButton() throws IOException {
		try {
			driver.findElement(By.xpath("//button[contains(@class,'undefined uiButton')]/span")).click();
			reportStep("Successfuly clicked save button","pass");
		} catch (Exception e) {
			reportStep("Failed to click the save button","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage clickOnDetails() throws IOException {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
			WebElement details = driver.findElement(By.xpath("//li[@title='Details']"));		
			try {
				details.click();
			} catch (Exception e2) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
				WebElement details1 = driver.findElement(By.xpath("//li[@title='Details']"));	
				driver.executeScript("arguments[0].click", details1);
			}
			reportStep("Successfuly clicked on details button","pass");
		} catch (Exception e) {
			reportStep("Failed click details button","fail"+e);
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage clickEditLeadStatus() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Edit Lead Status']")));
				driver.findElement(By.xpath("//button[@title='Edit Lead Status']")).click();
			} catch (Exception e3) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
				WebElement details1 = driver.findElement(By.xpath("//li[@title='Details']"));		
				try {
					details1.click();
				} catch (Exception e2) {
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
					WebElement details2 = driver.findElement(By.xpath("//li[@title='Details']"));	
					driver.executeScript("arguments[0].click", details2);
				}		
			}
			reportStep("Successfuly clicked edit lead status","pass");
		} catch (Exception e) {
			reportStep("Failed to click edit lead status","fail"+e);
		}		
		return this;
	}
	
	public NewlyCreatedLeadPage scrollToEditLeadStatus() throws IOException {
		try {
			try {
				WebElement scroll = driver.findElement(By.xpath("//label[text()='Rating']"));
				Actions obj=new Actions(driver);
				obj.scrollToElement(scroll).perform();
			} catch (NoSuchElementException e3) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Edit Lead Status']")));
				driver.findElement(By.xpath("//button[@title='Edit Lead Status']")).click();
				WebElement scroll  = driver.findElement(By.xpath("//label[text()='Rating']"));
				Actions obj=new Actions(driver);
				obj.scrollToElement(scroll).perform();
			}
			reportStep("Successfuly scrolled to edit lead status","pass");
		} catch (Exception e) {
			reportStep("Failed to scroll","fail"+e);
		}
			
		return this;
	}
	public NewlyCreatedLeadPage clickOnLeadstatusOptions() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
				driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")).click();
			} catch (ElementClickInterceptedException e) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
				WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
				driver.executeScript("arguments[0].click()", leadStatus);
			} catch (ElementNotInteractableException e) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
				WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
				driver.executeScript("arguments[0].click()", leadStatus);
			}
			reportStep("Successfuly clicked lead status options","pass");
		} catch (Exception e) {
			reportStep("Failed to click lead status options","fail"+e);
		}		
		return this;
	}
	public NewlyCreatedLeadPage selectTheLeadStatus() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
				WebElement status = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
				status.click();
			} catch (ElementClickInterceptedException e1) {
				WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));	
				driver.executeScript("arguments[0].click()", status1);
			} catch (ElementNotInteractableException e1) {
				WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));	
				driver.executeScript("arguments[0].click()", status1);
			} catch (TimeoutException e) {
				WebElement scroll  = driver.findElement(By.xpath("//label[text()='Rating']"));
				Actions obj=new Actions(driver);			
				obj.scrollToElement(scroll).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
				WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
				driver.executeScript("arguments[0].click()", leadStatus);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
				WebElement status = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
				status.click();
			}
			reportStep("Successfuly selected the lead status","pass");
		} catch (Exception e) {
			reportStep("Failed to select the lead status","fail"+e);
		}
		return this;
	}
	public NewlyCreatedLeadPage saveTheStatusChange() throws IOException {
		try {
			driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
			reportStep("Successfuly saved the status change","pass");
		} catch (Exception e) {
			reportStep("Failed to save the status change","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage scrollToMarkStatus() throws IOException {
		try {
			WebElement scroll1 = driver.findElement(By.xpath("//span[text()='Mark Status as Complete']"));
			Actions obj=new Actions(driver);
			obj.moveToElement(scroll1).perform();
			reportStep("Successfuly scrolled to mark status","pass");
		} catch (Exception e) {
			reportStep("Failed to scroll to mark status","fail"+e);
		}
		return this;
	}
	
	public NewlyCreatedLeadPage verifyingLeadStatusAndUpdate() throws IOException {
		try {
			String stageStatus = driver.findElement(By.xpath("//a[@title='Working - Contacted']/span[@class='title slds-path__title']")).getText();
			System.out.println("status of working contacted: "+stageStatus);
			if(stageStatus.contains("stage complete")) {
				System.out.println("Working - Contacted stage is marked as completed");
			}else {
				try {
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
					driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]")).click();
				} catch (Exception e) {
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
					WebElement markStatus = driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]"));
					driver.executeScript("arguments[0].click()", markStatus);
				}
			}
			reportStep("Successfuly verified lead status","pass");
		} catch (Exception e) {
			reportStep("Failed to verify the lead status","fail"+e);
		}
		return this;
		}
	
	public NewlyCreatedLeadPage clickShowMoreActions() throws IOException {
		try {
			try {
				driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			} catch (ElementClickInterceptedException e) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			} catch (ElementNotInteractableException e) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			}
			reportStep("Successfuly clicked widget to convert","pass");
		} catch (Exception e) {
			reportStep("Failed to click widget to convert","fail"+e);
		}
		return this;
	}

public NewlyCreatedLeadPage clickOnConvertOption() throws IOException {
	try {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
		} catch (ElementClickInterceptedException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (ElementNotInteractableException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (StaleElementReferenceException e) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
			} catch (ElementClickInterceptedException e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			}
		}
		reportStep("Successfuly clicked convert option","pass");
	} catch (Exception e) {
		reportStep("Failed to click convert option","fail"+e);
	}

		return this;
	}

public NewlyCreatedLeadPage clickOnConvertButton() throws IOException {
	try {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			driver.findElement(By.xpath("//button[text()='Convert']")).click();			
		} catch (Exception e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
			driver.executeScript("arguments[0].click()", convert1);
		}
		reportStep("Successfuly clicked convert button","pass");
	} catch (Exception e) {
		reportStep("Failed to click convert button","fail"+e);
	}
	return this;
}

public RecentlyViewedLeadsPage clickOnGoToLeadsButton() throws IOException {
	try {
		try {
			driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
		} catch (NoSuchElementException e) {
			driver.get(driver.getCurrentUrl());
			try {
				driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			} catch (Exception e1) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			} 
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
			} catch (ElementClickInterceptedException e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} catch (ElementNotInteractableException e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} 
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				driver.findElement(By.xpath("//button[text()='Convert']")).click();			
			} catch (Exception e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
				driver.executeScript("arguments[0].click()", convert1);
			}
			try {
				driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
			} catch (Exception e1) {
				driver.get(driver.getCurrentUrl());
				try {
					driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
				} catch (Exception e2) {
					WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
					driver.executeScript("arguments[0].click()", showMore);
				} 
				try {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
					driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
				} catch (ElementClickInterceptedException e2) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
					WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
					driver.executeScript("arguments[0].click()", dropDown2);
				} catch (ElementNotInteractableException e2) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
					WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
					driver.executeScript("arguments[0].click()", dropDown2);
				} 
				try {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
					driver.findElement(By.xpath("//button[text()='Convert']")).click();			
				} catch (Exception e2) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
					WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
					driver.executeScript("arguments[0].click()", convert1);
				}
				driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
			}
		}
		reportStep("Successfuly clicked go to leads button","pass");
	} catch (Exception e) {
		reportStep("Failed to click go to leads button","fail"+e);
	}
	return new RecentlyViewedLeadsPage();
}
	
}

			

