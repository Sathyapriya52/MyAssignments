package pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.BaseClass;

public class HomePage extends BaseClass {

	public HomePage clickToggleMenu() throws IOException {
		try {
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			reportStep("Successfully clicked the toggle menu","Pass");
		} catch (Exception e) {
			reportStep("Failed to click the Toggle menu","Fail"+e);
		}
		return this;
	}
	
public HomePage clickViewAll() throws IOException {
	wait=new WebDriverWait(driver, Duration.ofSeconds(30));
	try {
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='slds-icon-waffle']")));
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (StaleElementReferenceException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		reportStep("Successfully clicked view all button","Pass");
	} catch (Exception e) {
		reportStep("Failed to click view all button","Fail"+e);
	}
	return this;
		
	}

public SalesforceHomePage clickOnSales() throws IOException {
	try {
		try {
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (ElementNotInteractableException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (NoSuchElementException e1) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='slds-icon-waffle']")));
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}
		reportStep("Successfully clicked Sales button","Pass");
	} catch (Exception e) {
		reportStep("Failed to click the Sales button","Fail"+e);
	}
	return new SalesforceHomePage();
}




}
