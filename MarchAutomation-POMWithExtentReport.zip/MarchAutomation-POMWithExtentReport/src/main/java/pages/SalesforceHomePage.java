package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.BaseClass;

public class SalesforceHomePage extends BaseClass{
	
	public RecentlyViewedLeadsPage clickOnLeads() throws IOException {
		try {
			try {
				driver.findElement(By.xpath("(//span[text()='Leads'])[1]")).click();
			} catch (Exception e) {
				WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));			
				driver.executeScript("arguments[0].click()", leadsTab);
			}
			reportStep("Successfuly clicked Leads tab","pass");
		} catch (Exception e) {
			reportStep("Failed to click Leads tab","fail"+e);
		}
		return new RecentlyViewedLeadsPage();
	}

}
