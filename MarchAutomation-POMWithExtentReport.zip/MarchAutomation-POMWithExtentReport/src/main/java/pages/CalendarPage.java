package pages;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.BaseClass;

public class CalendarPage extends BaseClass {
	
	public CalendarPage windowsHandling() throws IOException {
		try {
			Set<String> windows = driver.getWindowHandles();
			   List<String> windowsList=new ArrayList<String>(windows);
			   driver.switchTo().window(windowsList.get(1));
			   String title = driver.getTitle();
			   System.out.println("Title of page: "+title);
			   reportStep("Successfuly handled the window","pass");
		} catch (Exception e) {
			reportStep("Failed to handle the window","fail"+e);
		} 		
		return this;
	}

	public CalendarPage clickOnNewEvent() throws IOException {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'new-event-button')]")));
			   driver.findElement(By.xpath("//button[contains(@class,'new-event-button')]")).click();
			   reportStep("Successfuly clicked on new event","pass");
		} catch (Exception e) {
			reportStep("Failed to click on new event","fail"+e);
		}
		return this;
	}
	
	public CalendarPage clickOnSubject() throws IOException {
		try {
			driver.findElement(By.xpath("//label[text()='Subject']/following-sibling::div")).click();
			reportStep("Successfuly clicked on subject","pass");
		} catch (Exception e) {
			reportStep("Failed to click on subject","fail"+e);
		}
		return this;
	}
	
	public CalendarPage selectSubject() throws IOException {
		try {
			driver.findElement(By.xpath("//span[@title='Meeting']")).click();
			reportStep("Successfuly selected the subject as meeting","pass");
		} catch (Exception e) {
			reportStep("Failed to select the subject as meeting","fail"+e);
		}
		return this;
	}
	
	public CalendarPage enterTheStartAndEndDate() throws IOException {
		try {
			LocalDate currentDate=LocalDate.now();
			LocalDate dayAfterTom=currentDate.plusDays(2);
			   System.out.println("Day after tomo is: "+dayAfterTom);
			   DateTimeFormatter format1=DateTimeFormatter.ofPattern("dd-MMM-yyyy");		
			   String dayAfterTomformatted = dayAfterTom.format(format1);      
			   System.out.println("Formatted date: "+dayAfterTomformatted);
			   WebElement startDate = driver.findElement(By.xpath("//legend[text()='Start']/following::input"));
			   startDate.clear();
			   startDate.sendKeys(dayAfterTomformatted,Keys.ENTER);
			   WebElement endDate = driver.findElement(By.xpath("//legend[text()='End']/following::input"));
			   endDate.clear();
			   endDate.sendKeys(dayAfterTomformatted,Keys.ENTER);
			   reportStep("Successfuly entered the start and end date","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the start and end date","fail"+e);
		}
		return this;
	}
	
	public CalendarPage enterMeetingDescription() throws IOException {
		try {
			Actions obj=new Actions(driver);
			obj.scrollToElement(driver.findElement(By.xpath("//span[text()='Description']"))).perform();
			   driver.findElement(By.xpath("//span[text()='Description']/following::textarea")).sendKeys("Discussion about the product"+Keys.ENTER);
			   reportStep("Successfuly entered the meeting description","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the meeting description","fail"+e);
		}
		return this;
	}
	
	public CalendarPage clickOnSaveMeeting() throws IOException {
		try {
			driver.findElement(By.xpath("//button[@title='Save']")).click();
			reportStep("Successfuly clicked on save meeting button","pass");
		} catch (Exception e) {
			reportStep("Failed to click on save meeting button","fail"+e);
		}
		return this;
	}
	
	public CalendarPage closeTheCalendar() throws IOException {
		try {
			driver.close();
			reportStep("Successfuly closed the calendar","pass");
		} catch (Exception e) {
			reportStep("Failed to close the calendar","fail"+e);
		}
		return this;
	}
	
}



