package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.BaseClass;

public class OpportunityPage extends BaseClass {

	public OpportunityPage clickOnProductWidget() throws IOException {
		try {
			WebElement showProduct = driver.findElement(By.xpath("//span[text()='Show actions for Products']"));
			driver.executeScript("arguments[0].click()", showProduct);
			reportStep("Successfuly clicked on product widget","pass");
		} catch (Exception e) {
			reportStep("Failed to click on product widget","fail"+e);
		}
		return this;
	}

	public OpportunityPage selectPriceBook() throws IOException {
		try {
			driver.findElement(By.xpath("//a[@title='Choose Price Book']")).click();
			reportStep("Successfuly selected price book","pass");
		} catch (Exception e) {
			reportStep("Failed to select price book","fail"+e);
		}
		return this;
	}

	public OpportunityPage clickOnPriceBookOptions() throws IOException {
		try {
			driver.findElement(By.xpath("//a[@class='select']")).click();
			reportStep("Successfuly clicked on price book options","pass");
		} catch (Exception e) {
			reportStep("Failed to click price book options","fail"+e);
		}
		return this;
	}

	public OpportunityPage selectStandardOption() throws IOException {
		try {
			WebElement priceBook = driver.findElement(By.xpath("//a[text()='Standard']"));
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a[text()='Standard']")));
			try {
				priceBook.click();
			} catch (ElementClickInterceptedException e) {
				driver.executeScript("arguments[0].click()", priceBook);
			}catch (ElementNotInteractableException e) {
				driver.executeScript("arguments[0].click()", priceBook);
			}
			reportStep("Successfuly selected the standard price book option","pass");
		} catch (Exception e) {
			reportStep("Failed to select the standard price book option","fail"+e);
		}
		return this;
	}

	public OpportunityPage clickOnSavePriceBook() throws IOException {
		try {
			driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
			reportStep("Successfuly clicked on save pricebook","pass");
		} catch (Exception e) {
			reportStep("Failed to click on save pricebook","fail"+e);
		}
		return this;
	}


	public OpportunityPage clickOnProductWidget1() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a")));
				WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));			
				showProduct1.click();
			} catch (ElementClickInterceptedException e) {
				WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));
				driver.executeScript("arguments[0].click()", showProduct1);	
			}
			reportStep("Successfuly clicked on product widget","pass");
		} catch (Exception e) {
			reportStep("Failed to click on prodcut widget","fail"+e);
		}
		return this;
	}

	public OpportunityPage selectAddProducts() throws IOException {
		try {
			driver.findElement(By.xpath("//a[@title='Add Products']")).click();
			reportStep("Successfuly selected add products","pass");
		} catch (Exception e) {
			reportStep("Failed to select add products","fail"+e);
		}
		return this;
	}

	public OpportunityPage enterSlaAndSearch() throws IOException {
		try {
			WebElement sla = driver.findElement(By.xpath("//input[@title='Search Products']"));
			sla.click();
			sla.sendKeys("SLA"+Keys.ENTER);
			reportStep("Successfuly entered sla and searched","pass");
		} catch (Exception e) {
			reportStep("Failed to enter search products","fail"+e);
		}
		return this;
	}

	public OpportunityPage clickOnSlaProducts() throws IOException {
		try {
			try {
				//driver.findElement(By.xpath("(//div[@data-aura-class='forceSearchInputLookupDesktopActionItem'])[1]")).click();
				driver.findElement(By.xpath("//span[text()='Search Products']")).click();
			} catch (ElementClickInterceptedException e) {
				WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
				driver.executeScript("arguments[0].click()", sla1);
			}catch (ElementNotInteractableException e) {
				WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
				driver.executeScript("arguments[0].click()", sla1);
			}
			reportStep("Successfuly clicked on sla Products","pass");
		} catch (Exception e) {
			reportStep("Failed to click on sla products","fail"+e);
		}
		return this;
	}

	public OpportunityPage selectAllProducts() throws IOException {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select 4 items']")));
			WebElement select = driver.findElement(By.xpath("//span[text()='Select 4 items']"));
			try {
				select.click();
			} catch (ElementClickInterceptedException e) {
				driver.executeScript("arguments[0].click()", select);
			}
			reportStep("Successfuly selected all the resulted products","pass");
		} catch (Exception e) {
			reportStep("Failed to select all the resulted products","fail"+e);
		}
		return this;
	}

	public OpportunityPage clickOnNext() throws IOException {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Next']")));
			driver.findElement(By.xpath("//span[text()='Next']")).click();
			reportStep("Successfuly clicked on next button","pass");
		} catch (Exception e) {
			reportStep("Failed to click on next button","fail"+e);
		}	
		return this;
	}

	public OpportunityPage editTheSelectedProducts() throws IOException {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Edit Selected Products']")));
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr/td[2]")));

			try {
				WebElement product = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));	
				product.click();
			} catch (Exception e1) {
				WebElement product = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));	
				driver.executeScript("arguments[0].click()", product);
			}

			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr/td[2]//input[@type='text']")).sendKeys("2"+Keys.ENTER);
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[2]/td[2]")).click();
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[2]/td[2]//input")).sendKeys("10"+Keys.ENTER);
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[3]/td[2]")).click();		
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[3]/td[2]//input")).sendKeys("1"+Keys.ENTER);
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[4]/td[2]")).click();
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[4]/td[2]//input")).sendKeys("5"+Keys.ENTER);
			reportStep("Successfuly entered the quantity for products","pass");
		} catch (Exception e) {
			reportStep("Failed to enter the quantity for products","fail"+e);
		}
		return this;
	}

	public OpportunityPage clickOnSaveProducts() throws IOException {
		try {
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Save']")));
			} catch (Exception e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Save']")));
			}
			WebElement save = driver.findElement(By.xpath("//button[@title='Save']"));
			save.click();
			reportStep("Successfuly clicked on save products","pass");
		} catch (Exception e) {
			reportStep("Failed to click on save products","fail"+e);
		}
		return this;
	}

	public OpportunityPage addAttachemnt() throws IOException {
		try {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage')]")));
			WebElement upload = driver.findElement(By.xpath("//input[@type='file']"));
			upload.sendKeys("C:\\Users\\sathy\\OneDrive\\Desktop\\Screenshot 2024-01-20 181042.png");
			reportStep("Successfuly added the attachment","pass");
		} catch (Exception e) {
			reportStep("Failed to add the attachment","fail"+e);
		}
		return this;
	}
	
	public OpportunityPage clickOnDone() throws IOException {
		try {
			try {			
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Done']/parent::button")));
				driver.findElement(By.xpath("//span[text()='Done']/parent::button")).click();
			} catch (ElementClickInterceptedException e) {
				WebElement done = driver.findElement(By.xpath("//span[text()='Done']/parent::button"));
				driver.executeScript("arguments[0].click()", done);
			}catch (ElementNotInteractableException e) {
				WebElement done = driver.findElement(By.xpath("//span[text()='Done']/parent::button"));
				driver.executeScript("arguments[0].click()", done);
			}
			reportStep("Successfuly clicked on done button","pass");
		} catch (Exception e) {
			reportStep("Failed to click on done button","fail"+e);
		}
		return this;
	}

	public OpportunityPage clickOnNewEventWidget() throws IOException {
		try {
			try {
				driver.findElement(By.xpath("(//span[@value='NewEvent'])[2]/following::button[@title='More Actions']")).click();
			} catch (Exception e) {
				WebElement newEvent = driver.findElement(By.xpath("(//span[@value='NewEvent'])[2]/following::button[@title='More Actions']"));
				driver.executeScript("arguments[0].click()", newEvent);
			}
			reportStep("Successfuly clicked on new event widget","pass");
		} catch (Exception e) {
			reportStep("Failed to click on new event widget","fail"+e);
		}
		return this;
	}
	
	public CalendarPage clickOnViewCalendar() throws IOException {
		try {
			try {
				driver.findElement(By.xpath("//span[text()='View Calendar']")).click();
			} catch (Exception e) {
				WebElement viewCalendar = driver.findElement(By.xpath("//span[text()='View Calendar']"));
				driver.executeScript("arguments[0].click()", viewCalendar);
			}
			reportStep("Successfuly clicked on view calendar","pass");
		} catch (Exception e) {
			reportStep("Failed to click on view calendar","fail"+e);
		}
		return new CalendarPage();
	}	
	
}
