package pages;


import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.BaseClass;

public class LoginPage extends BaseClass {

	
	public LoginPage enterUsername() throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
			reportStep("Entered the username successfully","Pass");
		} catch (Exception e) {
			reportStep("Failed to enter the username","Fail"+e);
		}
		return this;
	}

	public LoginPage enterPassword() throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys("Testleaf@123");
			reportStep("Entered the password successfully","Pass");
		} catch (Exception e) {
			reportStep("Failed to enter the password","Fail"+e);
		}
		return this;
	}

	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.id("Login")).click();
			reportStep("Logged in successfully","Pass");
		} catch (Exception e) {
			reportStep("Failed to login","Fail"+e);
		}	
		return  new HomePage();
	}

}


