package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class BaseClass {
	public static ChromeDriver driver;	
	public static WebDriverWait wait;
	public static String lastName;
	public static String companyName;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String testcaseName,testcaseDescription,author,category;


	@BeforeSuite
	public void starReport() {

		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./report/result.html");		
		reporter.setAppendExisting(true);
		extent=new ExtentReports();
		extent.attachReporter(reporter);
	}
	@BeforeClass
	public void testDetails() {
		test=extent.createTest(testcaseName, testcaseDescription);
		test.assignCategory(category);
		test.assignAuthor(author);
	}

	public void reportStep(String setpInfo,String status) throws IOException {
		int randomSnap = takeSnap();//This step is to get the snap number
		if(status.equalsIgnoreCase("pass")) {
			test.pass(setpInfo,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+randomSnap+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			test.fail(setpInfo,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+randomSnap+".png").build());
		}
	}
	
	public int takeSnap() throws IOException {
		
		int randomNumber=(int) ((Math.random())*999999);
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File destination=new File("./snap/img"+randomNumber+".png");
		FileUtils.copyFile(screenshotAs, destination);
		return randomNumber;
	}

	@BeforeMethod
	public void preCondtion() throws IOException {

		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");			
		driver=new ChromeDriver(options);			
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();			
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	//@AfterMethod
	//public void postCondition() {
	//driver.close();
	//}
	
	@AfterSuite
	public void stopReport() {
		extent.flush();
	}
}
