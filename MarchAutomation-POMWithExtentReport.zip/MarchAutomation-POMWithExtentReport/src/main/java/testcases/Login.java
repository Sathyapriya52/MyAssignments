package testcases;


import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class Login extends BaseClass {

    @BeforeTest
	public void setTestDate() {
		testcaseName="LeadConversion and Opportunity Management";
		testcaseDescription="Create a lead and convert it to an Opportunity and manage it";
		author="Sathyapriya";				
		category="Functional Testing";
	}


	@Test
	public void runLogin() throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton().clickToggleMenu().clickViewAll().clickOnSales().clickOnLeads().clickOnNewButton()
		.selectSalutation().enterLasrname().enterCompanyName().clickOnSave().verifyingLeadNameAndCompanyName().clickOnEmailWidget()		
		.clickOnAddEmailToDoList().selectTheSubject().selectEmailAsSubject().clickTheDueDate().selectTheDueDate().clickTheStatusOption().selectTheInprogressStatus()
		.saveTheToDoList().clickOnEmailButton().enterEmailAddress().enterTheMailSubject().enterEmailBody()
		.clickOnSend().clickOnShowMoreActions().clickChangeStatus().changeStausOptions().selectCompletedStatus().clickOnSaveButton().clickOnDetails()
		.clickEditLeadStatus().scrollToEditLeadStatus().clickOnLeadstatusOptions().selectTheLeadStatus().saveTheStatusChange().scrollToMarkStatus()
		.verifyingLeadStatusAndUpdate().clickShowMoreActions().clickOnConvertOption().clickOnConvertButton().clickOnGoToLeadsButton().verifyTheLeadConversion()
		.clickOnOpportunityTab().enterTheOpportunityNameAndSearch().selectTheOpportunity().clickOnProductWidget().selectPriceBook().clickOnPriceBookOptions()
		.selectStandardOption().clickOnSavePriceBook().clickOnProductWidget1().selectAddProducts().enterSlaAndSearch().clickOnSlaProducts().selectAllProducts()
		.clickOnNext().editTheSelectedProducts().clickOnSaveProducts().addAttachemnt().clickOnDone().clickOnNewEventWidget().clickOnViewCalendar().windowsHandling()
		.clickOnNewEvent().clickOnSubject().selectSubject().enterTheStartAndEndDate().enterMeetingDescription().clickOnSaveMeeting().closeTheCalendar();	   

	}
}
