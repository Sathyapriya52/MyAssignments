package opportunity;

import java.io.File;
import java.io.IOException;
import java.time.Duration;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Step6UpdateOpportunity {

	public static void main(String[] args) throws InterruptedException, IOException {
		//Disable notification
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(option);		
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//Login: Log in to the Salesforce account at https://login.salesforce.com.
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();

		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));

		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (StaleElementReferenceException e2) {			
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		try {
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch(NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			try {
				driver.findElement(By.xpath("//p[text()='Sales']")).click();
			} catch (StaleElementReferenceException e) {
				driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
				WebElement viewAll1 = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
				viewAll1.click();
				driver.findElement(By.xpath("//p[text()='Sales']")).click();
			}
		}

		//Open Opportunities: Navigate to the 'Opportunities' tab.
		WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
		driver.executeScript("arguments[0].click()", opp);

		//Search and Open Opportunity: Search for the opportunity associated with the converted lead by company name.

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Opportunity-search-input']")));
		driver.findElement(By.xpath("//input[@name='Opportunity-search-input']")).sendKeys("TCS"+Keys.ENTER);		
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@data-refid='recordId'])[1]")));
			driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]")).click();			
		} catch (StaleElementReferenceException e1) {
			driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]")).click();
		}

		//Verify Details: Confirm the account name (company name from the lead) at the top left of the webpage
		//and verify the contact (your name) at the right bottom.
		String accountName = driver.findElement(By.xpath("//p[text()='Account Name']/following-sibling::p")).getText();		
		System.out.println("The account name is: "+accountName);
		if(accountName.contains("TCS")) {
			System.out.println("The account name is valid");
		}else {
			System.out.println("The account name is invalid");
		}
		String contactName = driver.findElement(By.xpath("//div[@class='primaryColumnLeft']//a")).getText();
		System.out.println("The contact name is: "+contactName);
		if(contactName.contains("Vijay")) {
			System.out.println("The contact name is valid");
		}else {
			System.out.println("The contact name is invalid");
		}

		//Create New Task: Click on the new task icon under 'Activity', choose subject as 'email', 
		driver.findElement(By.xpath("//span[@value='NewTask']")).click();
		driver.findElement(By.xpath("(//label[text()='Subject']/following::div)[1]")).click();
		driver.findElement(By.xpath("//span[@title='Email']/parent::span")).click();

		//set due date as today's date, and verify correct assignment of contact and related opportunity.
		WebElement date = driver.findElement(By.xpath("//button[@title='Select a date for Due Date']"));
		driver.executeScript("arguments[0].click()", date);
		driver.findElement(By.xpath("//td[@class='slds-is-today']")).click();
		driver.findElement(By.xpath("//input[@title='Search Contacts']")).click();
		driver.findElement(By.xpath("(//div[contains(@class,'slds-m-left--smalllabels')])[1]")).click();
		String relatedTo = driver.findElement(By.xpath("(//span[@class='pillText'])[2]")).getText();
		System.out.println("The related opportunity is: "+relatedTo);
		if(relatedTo.contains("TCS")) {
			System.out.println("The related opportunity is valid");
		}else {
			System.out.println("The related opportunity is invalid");
		}
		//Update Task Status: Change the task status to 'In Progress' and click 'Save'.
		/*driver.findElement(By.xpath("//span[text()='Status']/following::div")).click();
		driver.findElement(By.xpath("//a[@title='In Progress']")).click();
		driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
		//Send Email: Click on the email icon under 'Activity', compose an email to the opportunity, and click 'Send'.
		WebElement email = driver.findElement(By.xpath("//span[@value='SendEmail']"));
		driver.executeScript("arguments[0].click()", email);
		driver.findElement(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")).sendKeys("vijay@tcs.com");
		driver.findElement(By.xpath("//input[@placeholder='Enter Subject...']")).sendKeys("Mail regarding opportunity");
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(0));
		WebElement iframe1 = driver.findElement(By.xpath("//iframe[@title='Email Body']"));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(iframe1));
		//driver.switchTo().frame(iframe1);
		driver.findElement(By.xpath("//body[@contenteditable='true']")).clear();
		driver.findElement(By.xpath("//body[@contenteditable='true']")).sendKeys("This email is a test email");
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[text()='Send']")).click();*/

		//Check Email Status: Click on the widget icon for the email under 'Upcoming & Overdue', change status to 'Completed', and save.
		WebElement action = driver.findElement(By.xpath("(//span[text()='Show more actions'])[3]"));
		driver.executeScript("arguments[0].click()", action);		
		WebElement status = driver.findElement(By.xpath("//div[@title='Change Status']"));
		driver.executeScript("arguments[0].click()", status);
		WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
		wait.until(ExpectedConditions.visibilityOf(select));
		try {
			select.click();
		} catch (ElementClickInterceptedException e1) {
			WebElement select1 = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select1);
		} catch(StaleElementReferenceException e) {
			driver.findElement(By.xpath("//a[@class='select']")).click();			
		}catch (ElementNotInteractableException e1) {
			WebElement select1 = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select1);
		}
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Completed']")));
		driver.findElement(By.xpath("//a[@title='Completed']")).click();
		try {
			driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
		} catch (Exception e1) {
			WebElement saveStatus = driver.findElement(By.xpath("(//span[text()='Save'])[3]"));
			driver.executeScript("arguments[0].click()", saveStatus);
		}

		//Edit Opportunity Stage: Click on the widget icon for the opportunity at the top right, 
		//click 'Edit', change the stage to 'Qualification', and click 'Save'.
		WebElement dropDown = driver.findElement(By.xpath("//span[text()='Show more actions']"));
		driver.executeScript("arguments[0].click()", dropDown);
		WebElement edit = driver.findElement(By.xpath("//span[text()='Edit']"));
		driver.executeScript("arguments[0].click()", edit);
		driver.findElement(By.xpath("//label[text()='Stage']/following-sibling::div")).click();
		WebElement dropDown1 = driver.findElement(By.xpath("//span[@title='Qualification']"));
		driver.executeScript("arguments[0].click()", dropDown1);
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()='Save'])[2]")));
			driver.findElement(By.xpath("//button[text()='Save']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save);
		} catch (ElementNotInteractableException e) {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save);
		}

		//Take Snapshot: Capture a screenshot of the webpage.
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage sld')]")));
		File screenShot=driver.getScreenshotAs(OutputType.FILE);	
		File destination=new File("./snapshot/opp.jpg");
		FileUtils.copyFile(screenShot, destination);
	}
}
