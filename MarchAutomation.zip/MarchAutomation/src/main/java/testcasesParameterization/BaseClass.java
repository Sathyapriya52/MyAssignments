package testcasesParameterization;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BaseClass {
	public ChromeDriver driver;
	public static String lastName;
	public static String companyName;
	public WebDriverWait wait;
	
@Parameters({"url","username","password"})	
@BeforeMethod
	public void preCondtion(String url,String username,String password) {
		//Turn off notification
				ChromeOptions options=new ChromeOptions();
				options.addArguments("--disable-notifications");
				//Launch the browser
				driver=new ChromeDriver(options);
				//Load the URL
				driver.get(url);
				//Maximize the window
				driver.manage().window().maximize();
				// Add  implicitlyWait
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				//Login to the application
				driver.findElement(By.id("username")).sendKeys(username);
				driver.findElement(By.id("password")).sendKeys(password);
				driver.findElement(By.id("Login")).click();				
	}
@AfterMethod
public void postCondition() {
	driver.close();
}

}
