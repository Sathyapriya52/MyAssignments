package testcasesParameterization;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AssetLibrary extends BaseClass  {
	
	@Test
	public void library() throws IOException {
		
		//Switch to Salesforce Classic:Click on the 'profile' and select 'Switch to Salesforce Classic.'
		try {
			WebElement profile = driver.findElement(By.xpath("//span[text()='View profile']"));
			driver.executeScript("arguments[0].click()", profile);
			driver.findElement(By.xpath("//a[text()='Switch to Salesforce Classic']")).click();
		} catch (Exception e) {
			
		}				
		//Ensure that the switch occurs only if not already in Salesforce Classic.	
		boolean displayed = driver.findElement(By.xpath("//div[@id='AppBodyHeader']")).isDisplayed();
		Assert.assertTrue(displayed);
		
		
		//Navigate to Libraries:Click on the 'Libraries' tab
		try {
			driver.findElement(By.xpath("//a[@title='Libraries Tab']")).click();
		} catch (Exception e1) {
			WebElement library = driver.findElement(By.xpath("//a[@title='Libraries Tab']"));
			driver.executeScript("arguments[0].click", library);
		}
		//Select Asset Library:Choose 'Asset Library' from the 'Manage Library' dropdown.
		WebElement selectLibrary = driver.findElement(By.xpath("//select[@name='selectedWorkspaceId']"));
		Select sel=new Select(selectLibrary);
		sel.selectByIndex(1);
		//Initiate Contribution: Click on the 'Contribute' button.
		 wait=new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Contribute']")));
		driver.findElement(By.xpath("//button[text()='Contribute']")).click();
		//Link to Website:Click on the 'Do you want to link to a website instead?' link.
		driver.findElement(By.xpath("//a[text()='Do you want to link to a website instead?']")).click();
		
		//Enter URL:In the URL bar, input http://randomName.com.
		WebElement url = driver.findElement(By.xpath("//input[@id='contentUrl']"));
		url.clear();
		url.sendKeys("http://randomName.com");
	
		//Complete Contribution:Click on the 'Contribute' button.
        driver.findElement(By.xpath("//div[@class='buttons']/button[text()='Contribute']")).click();
		//Provide Title: Enter the title as 'About Random name.'
        WebElement title = driver.findElement(By.xpath("//input[@class='describeTitle text']"));
        title.clear();
        title.sendKeys("About Random name");  
        System.out.println("Name is entered");
        //Save Contribution: Click on the 'Save' button.       
    	driver.findElement(By.xpath("//table[@id='publishBtn']")).click();
    	//Capture Snapshot: Take a snapshot of the 'Save or publish content' screen.
    	// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[@id='header2']")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[text()='Done Publishing']")));
    	File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
    	File destination=new File("./snapshot/library.jpg");
    	FileUtils.copyFile(screenshotAs, destination);
    	//Complete Publishing: Click on 'Done publishing.'
    	driver.findElement(By.xpath("//button[text()='Done Publishing']")).click();
		
	}

}
