package testcasesLeadConversionAndOpportunityManagement;

import java.util.Base64;

public class EncodeCredentials {


	public static void main(String[] args) {

		String userName="sathyapriya.v@gmail.com";
		String password="Testleaf@123";
		
		String encodeToString = Base64.getEncoder().encodeToString(userName.getBytes());
		String encodeToString2 = Base64.getEncoder().encodeToString(password.getBytes());
		System.out.println(encodeToString);
		System.out.println(encodeToString2);
	}

}
