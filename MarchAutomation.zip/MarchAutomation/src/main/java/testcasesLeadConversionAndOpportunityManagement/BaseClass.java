package testcasesLeadConversionAndOpportunityManagement;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Base64;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;

public class BaseClass {

	public ChromeDriver driver;
	public static String lastName;
	public static String companyName;
	public WebDriverWait wait;
	public static Properties prop;


	@BeforeMethod
	public void preCondtion() throws IOException {

		//Set up the property file path
		FileInputStream fis=new FileInputStream("./src/main/resources/cofig.properties");
		//Create obj for Property file
		prop=new Properties();
		//Load the property file
		prop.load(fis);
		
		//Turn off notification
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		//Launch the browser
		driver=new ChromeDriver(options);
		//Load the URL
		driver.get(prop.getProperty("url"));
		//Maximize the window
		driver.manage().window().maximize();
		// Add  implicitlyWait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//Login to the application
		
		driver.findElement(By.id("username")).sendKeys(new String(Base64.getDecoder().decode(prop.getProperty("userName"))));
		driver.findElement(By.id("password")).sendKeys(new String(Base64.getDecoder().decode(prop.getProperty("password"))));
		driver.findElement(By.id("Login")).click();	
		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@aria-label='View All Applications']")));
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@aria-label='View All Applications']")));
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (StaleElementReferenceException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (TimeoutException e) {
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		try {
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Sales']")));
			} catch (TimeoutException e) {						
				driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
				try {
					driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
				} catch (StaleElementReferenceException e1) {
					driver.get(driver.getCurrentUrl());
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-icon-waffle']")));
					driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
					driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
				}
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Sales']")));
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {					
			WebElement sales;
			try {
				sales = driver.findElement(By.xpath("//p[text()='Sales']"));
				driver.executeScript("arguments[0].click()", sales);	
			} catch (NoSuchElementException e1) {
				driver.get(driver.getCurrentUrl());
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-icon-waffle']")));
				driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
				driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
				try {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Sales']")));
					driver.findElement(By.xpath("//p[text()='Sales']")).click();
				} catch (Exception e2) {
					driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
					driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
					driver.findElement(By.xpath("//p[text()='Sales']")).click();
				}
			}

		}catch (ElementNotInteractableException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='slds-icon-waffle']")));
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Sales']")));
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}
	}
	/*@AfterMethod
public void postCondition() {
	driver.close();

}*/
}
