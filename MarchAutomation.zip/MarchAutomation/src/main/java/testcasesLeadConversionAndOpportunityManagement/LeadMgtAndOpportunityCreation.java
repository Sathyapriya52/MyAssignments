package testcasesLeadConversionAndOpportunityManagement;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class LeadMgtAndOpportunityCreation extends BaseClass {

	@Test
	public void leadCreation() {

		//Open Leads: Navigate to the 'Leads' tab.
		try {
			driver.findElement(By.xpath("(//span[text()='Leads'])[1]")).click();
		} catch (Exception e) {
			WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));			
			driver.executeScript("arguments[0].click()", leadsTab);
		}
		//Create New Lead: Click on the 'New' button.
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='New']")));
		driver.findElement(By.xpath("//div[text()='New']")).click();

		//Enter Information: Fill in the Last Name,Company Name 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='lastName']")));
		Faker fake=new Faker();
		lastName = fake.name().lastName();
		companyName = fake.company().name();
		driver.findElement(By.xpath("(//div[@class='slds-combobox_container'])[2]")).click();
		driver.findElement(By.xpath("//span[@title='Ms.']")).click();
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);			
		driver.findElement(By.xpath("//input[@name='Company']")).sendKeys(companyName);

		//Save Changes: Click 'Save'.
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();

		//Check that the lead name and company name are correct (use TestNG Assertion).
		String actulaLeadName = driver.findElement(By.xpath("//slot[@name='primaryField']/lightning-formatted-name")).getText();		
		String expectedLeadName="Ms. "+lastName;
		Assert.assertEquals(actulaLeadName, expectedLeadName);	
		String actualCompanyName = driver.findElement(By.xpath("//p[@title='Company']/following::lightning-formatted-text")).getText();			
		String expectedCompanyName=companyName;
		Assert.assertEquals(actualCompanyName, expectedCompanyName);


		//Create a to-do list item for sending an email.
		try {
			WebElement emailWidget = driver.findElement(By.xpath("//button[@title='Email']/following::button"));
			emailWidget.click();
		} catch (Exception e1) {
			WebElement emailWidget = driver.findElement(By.xpath("//button[@title='Email']/following::button"));
			driver.executeScript("arguments[0].click()", emailWidget);
		}		
		driver.findElement(By.xpath("//span[text()='Add Email to To Do List']")).click();

		//Set the subject as "Email", due date as today's date (use Java Date class), and status as 'In Progress'.
		driver.findElement(By.xpath("(//label[text()='Subject']/following::div)[1]")).click();
		driver.findElement(By.xpath("(//span[text()='Email']/parent::span)[2]")).click();
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Due Date']")));
			driver.findElement(By.xpath("//label[text()='Due Date']")).click();
		} catch (Exception e) {
			WebElement date = driver.findElement(By.xpath("//label[text()='Due Date']"));
			driver.executeScript("arguments[0].click()", date);
		}
		//Get Today's date
		LocalDate currentDate=LocalDate.now();
		System.out.println("Today date is: "+currentDate);
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");	
		String date = currentDate.format(format);
		System.out.println(date);
		WebElement dueDate = driver.findElement(By.xpath("//span[text()='Due Date']/following::input"));
		dueDate.sendKeys(date,Keys.ENTER);
		driver.findElement(By.xpath("//a[@class='select']")).click();		 
		driver.findElement(By.xpath("//a[@title='In Progress']")).click();

		//Save the to-do list.
		driver.findElement(By.xpath("//button[contains(@class,'ShareButton uiButton')]")).click();

		//Send Email to Lead:
		//Click on the email in the to-do list.
		try {
				driver.findElement(By.xpath("//span[@value='SendEmail']")).click();
			} catch (Exception e) {
				WebElement email = driver.findElement(By.xpath("//span[@value='SendEmail']"));
				driver.executeScript("arguments[0].click()", email);
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")));

			//Compose an email to the lead's email address (lastname@companyname.com).
			String company=companyName.replaceAll("[^a-zA-Z]", " ");
			String finalCompanyName = company.replaceAll(" ","");
			System.out.println("Company name is: "+finalCompanyName);
			driver.findElement(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]")).sendKeys(lastName+"@"+finalCompanyName+".com");
			driver.findElement(By.xpath("//input[@placeholder='Enter Subject...']")).sendKeys("New Lead");
			//Switch to parent frame
			WebElement iframe = driver.findElement(By.xpath("//iframe[@title='CK Editor Container']"));
			driver.switchTo().frame(iframe);
			//Switch to child frame
			WebElement iframe1 = driver.findElement(By.xpath("//iframe[@title='Email Body']"));
			driver.switchTo().frame(iframe1);
			driver.findElement(By.xpath("//body[@contenteditable='true']")).clear();
			driver.findElement(By.xpath("//body[@contenteditable='true']")).sendKeys("This email is a test email");
			driver.switchTo().defaultContent();

			//Send the email.
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'send uiButton')]")));
			driver.findElement(By.xpath("//button[contains(@class,'send uiButton')]")).click();
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage sld')]")));

		//Update To-Do List Status:Set the status of the email to-do list item as 'Completed'.
		try {
			WebElement action = driver.findElement(By.xpath("//a[contains(@class,'rowActionsPlaceHolder')]//span[text()='Show more actions']"));
			action.click();
		} catch (Exception e1) {
			WebElement action = driver.findElement(By.xpath("//a[contains(@class,'rowActionsPlaceHolder')]//span[text()='Show more actions']"));
			driver.executeScript("arguments[0].click()", action);
		}

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")));
			driver.findElement(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")).click();
		} catch (Exception e2) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div")));
			WebElement changeStatus = driver.findElement(By.xpath("//a[contains(@data-target-selection-name,'UpdateStatus')]/div"));
			driver.executeScript("arguments[0].click()", changeStatus);
		}
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='select']")));
			driver.findElement(By.xpath("//a[@class='select']")).click();				
		} catch(ElementClickInterceptedException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select);
		}catch(ElementNotInteractableException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select);
		}
		driver.findElement(By.xpath("//a[@title='Completed']")).click();
		driver.findElement(By.xpath("//button[contains(@class,'undefined uiButton')]/span")).click();

		//Change Lead Status:Navigate to the lead's details.
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
		WebElement details = driver.findElement(By.xpath("//li[@title='Details']"));		
		try {
			details.click();
		} catch (Exception e2) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
			WebElement details1 = driver.findElement(By.xpath("//li[@title='Details']"));	
			driver.executeScript("arguments[0].click", details1);
		}		
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Edit Lead Status']")));
			driver.findElement(By.xpath("//button[@title='Edit Lead Status']")).click();
		} catch (Exception e3) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
			WebElement details1 = driver.findElement(By.xpath("//li[@title='Details']"));		
			try {
				details1.click();
			} catch (Exception e2) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[@title='Details']")));
				WebElement details2 = driver.findElement(By.xpath("//li[@title='Details']"));	
				driver.executeScript("arguments[0].click", details2);
			}		
		}		

		try {
			WebElement scroll = driver.findElement(By.xpath("//label[text()='Rating']"));
			Actions obj=new Actions(driver);
			obj.scrollToElement(scroll).perform();
		} catch (NoSuchElementException e3) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Edit Lead Status']")));
			driver.findElement(By.xpath("//button[@title='Edit Lead Status']")).click();
			WebElement scroll  = driver.findElement(By.xpath("//label[text()='Rating']"));
			Actions obj=new Actions(driver);
			obj.scrollToElement(scroll).perform();
		}

		///Change the lead status to 'Working - Contacted'
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")).click();
		} catch (ElementClickInterceptedException e) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
		} catch (ElementNotInteractableException e) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
		}		

		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
			WebElement status = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
			status.click();
		} catch (ElementClickInterceptedException e1) {
			WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));	
			driver.executeScript("arguments[0].click()", status1);
		} catch (ElementNotInteractableException e1) {
			WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));	
			driver.executeScript("arguments[0].click()", status1);
		} catch (TimeoutException e) {
			WebElement scroll  = driver.findElement(By.xpath("//label[text()='Rating']"));
			Actions obj=new Actions(driver);			
			obj.scrollToElement(scroll).perform();
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")));
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
			WebElement status = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
			status.click();
		}
		//Save the lead details.
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		WebElement scroll1 = driver.findElement(By.xpath("//span[text()='Mark Status as Complete']"));
		Actions obj=new Actions(driver);
		obj.moveToElement(scroll1).perform();

		//Check Status Completion: If the lead status 'Working - Contacted' is not marked as completed, click on 'Mark Status as Complete'.		

		String stageStatus = driver.findElement(By.xpath("//a[@title='Working - Contacted']/span[@class='title slds-path__title']")).getText();
		System.out.println("status of working contacted: "+stageStatus);
		if(stageStatus.contains("stage complete")) {
			System.out.println("Working - Contacted stage is marked as completed");
		}else {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
				driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]")).click();
			} catch (Exception e) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
				WebElement markStatus = driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]"));
				driver.executeScript("arguments[0].click()", markStatus);
			}

		}
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage')]")));
		String stageStatus1;
		try {
			stageStatus1 = driver.findElement(By.xpath("//a[@title='Working - Contacted']//span[@class='slds-assistive-text']")).getText();
			System.out.println("Final status: "+stageStatus1);
		} catch (Exception e3) {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
				driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]")).click();
			} catch (Exception e) {
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'Action current uiButton')]")));
				WebElement markStatus = driver.findElement(By.xpath("//button[contains(@class,'Action current uiButton')]"));
				driver.executeScript("arguments[0].click()", markStatus);
			}	
		}


		//Convert Lead:Convert the lead into an opportunity.

		try {
			driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		} catch (ElementNotInteractableException e) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		}
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
		} catch (ElementClickInterceptedException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (ElementNotInteractableException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
			WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (StaleElementReferenceException e) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
			} catch (ElementClickInterceptedException e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			}
		}

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			driver.findElement(By.xpath("//button[text()='Convert']")).click();			
		} catch (Exception e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
			driver.executeScript("arguments[0].click()", convert1);
		}

		//Verify that the lead is removed from the lead list.

		try {
			driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
		} catch (NoSuchElementException e) {
			driver.get(driver.getCurrentUrl());
			try {
				driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			} catch (Exception e1) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			} 
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
			} catch (ElementClickInterceptedException e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} catch (ElementNotInteractableException e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
				WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} 
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				driver.findElement(By.xpath("//button[text()='Convert']")).click();			
			} catch (Exception e1) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
				driver.executeScript("arguments[0].click()", convert1);
			}
			try {
				driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
			} catch (Exception e1) {
				driver.get(driver.getCurrentUrl());
				try {
					driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
				} catch (Exception e2) {
					WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
					driver.executeScript("arguments[0].click()", showMore);
				} 
				try {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
					driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")).click();
				} catch (ElementClickInterceptedException e2) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
					WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
					driver.executeScript("arguments[0].click()", dropDown2);
				} catch (ElementNotInteractableException e2) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span")));
					WebElement dropDown2 = driver.findElement(By.xpath("//lightning-menu-item[contains(@data-target-selection-name,'Lead.Convert')]//span"));
					driver.executeScript("arguments[0].click()", dropDown2);
				} 
				try {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
					driver.findElement(By.xpath("//button[text()='Convert']")).click();			
				} catch (Exception e2) {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
					WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
					driver.executeScript("arguments[0].click()", convert1);
				}
				driver.findElement(By.xpath("//button[text()='Go to Leads']")).click();
			}
		}
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+ Keys.ENTER);	

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")));
		} catch (Exception e) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
			driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+ Keys.ENTER);	
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")));
		}
		String leadVerification = driver.findElement(By.xpath("//div[@data-aura-class='uiScroller']/following::lightning-formatted-rich-text")).getText();
		System.out.println("LeadVerification: "+leadVerification);
		if(leadVerification.contains("No items to display.")) {
			System.out.println("The lead is removed from the lead list");
		}else {
			System.out.println("The lead is not removed from the lead list");  
		}

		//Add SLA Products to Opportunity:Open the opportunity converted from the lead (company name).
		//Open Leads: Navigate to the 'opportunity' tab.
		WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
		driver.executeScript("arguments[0].click()", opp);	
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@name='Opportunity-search-input']")));
		driver.findElement(By.xpath("//input[@name='Opportunity-search-input']")).sendKeys(companyName+Keys.ENTER);		
		try {
			driver.findElement(By.xpath("//a[@title='"+companyName+"-']")).click();
		} catch (StaleElementReferenceException e1) {			
			driver.findElement(By.xpath("//a[@title='"+companyName+"-']")).click();
		}catch (ElementClickInterceptedException e1) {			
			WebElement record = driver.findElement(By.xpath("//a[@title='"+companyName+"-']"));
			driver.executeScript("arguments[0].click()", record);
		}catch (ElementNotInteractableException e1) {			
			WebElement record = driver.findElement(By.xpath("//a[@title='"+companyName+"-']"));
			driver.executeScript("arguments[0].click()", record);
		}

		//Add SLA products to the opportunity.
		//Select Price Book: Click on the widget for the product under 'Related', choose 'Choose Price Book', select 'Standard', and click 'Save'.
		WebElement showProduct = driver.findElement(By.xpath("//span[text()='Show actions for Products']"));
		driver.executeScript("arguments[0].click()", showProduct);
		driver.findElement(By.xpath("//a[@title='Choose Price Book']")).click();
		driver.findElement(By.xpath("//a[@class='select']")).click();
		WebElement priceBook = driver.findElement(By.xpath("//a[text()='Standard']"));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a[text()='Standard']")));
		try {
			priceBook.click();
		} catch (ElementClickInterceptedException e) {
			driver.executeScript("arguments[0].click()", priceBook);
		}catch (ElementNotInteractableException e) {
			driver.executeScript("arguments[0].click()", priceBook);
		}
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();

		//Enter the quantity for each product.
		//Add Products: Click on the widget for the product under 'Related', click 'Add Products'.

		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a")));
			WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));			
			showProduct1.click();
		} catch (ElementClickInterceptedException e) {
			WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));
			driver.executeScript("arguments[0].click()", showProduct1);	
		}
		driver.findElement(By.xpath("//a[@title='Add Products']")).click();
		WebElement sla = driver.findElement(By.xpath("//input[@title='Search Products']"));
		sla.click();
		sla.sendKeys("SLA"+Keys.ENTER);

		try {
			//driver.findElement(By.xpath("(//div[@data-aura-class='forceSearchInputLookupDesktopActionItem'])[1]")).click();
			driver.findElement(By.xpath("//span[text()='Search Products']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
			driver.executeScript("arguments[0].click()", sla1);
		}catch (ElementNotInteractableException e) {
			WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
			driver.executeScript("arguments[0].click()", sla1);
		}
		//Select Products: Click on 'Select All' checkbox, click 'Next', and enter the quantities for 
		//each product type (Platinum - 1, Gold - 2, Silver - 5, Bronze - 10).
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select 4 items']")));
		WebElement select = driver.findElement(By.xpath("//span[text()='Select 4 items']"));
		try {
			select.click();
		} catch (ElementClickInterceptedException e) {
			driver.executeScript("arguments[0].click()", select);
		}
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Next']")));
		driver.findElement(By.xpath("//span[text()='Next']")).click();	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Edit Selected Products']")));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr/td[2]")));
		
		try {
			WebElement product = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));	
			product.click();
		} catch (Exception e1) {
			WebElement product = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));	
			driver.executeScript("arguments[0].click()", product);
		}
		
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr/td[2]//input[@type='text']")).sendKeys("2"+Keys.ENTER);
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[2]/td[2]")).click();
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[2]/td[2]//input")).sendKeys("10"+Keys.ENTER);
			driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[3]/td[2]")).click();		
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[3]/td[2]//input")).sendKeys("1"+Keys.ENTER);
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[4]/td[2]")).click();
		driver.findElement(By.xpath("//table[@data-aura-class='uiVirtualDataTable']/tbody//tr[4]/td[2]//input")).sendKeys("5"+Keys.ENTER);

		//Save the opportunity.
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Save']")));
		} catch (Exception e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@title='Save']")));
		}
		WebElement save = driver.findElement(By.xpath("//button[@title='Save']"));
		save.click();

		//Add Notes and Attachments:Add notes and attachments to the opportunity.
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage')]")));
		WebElement upload = driver.findElement(By.xpath("//input[@type='file']"));
		upload.sendKeys("C:\\Users\\sathy\\OneDrive\\Desktop\\Screenshot 2024-01-20 181042.png");
		try {			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Done']/parent::button")));
			driver.findElement(By.xpath("//span[text()='Done']/parent::button")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement done = driver.findElement(By.xpath("//span[text()='Done']/parent::button"));
			driver.executeScript("arguments[0].click()", done);
		}catch (ElementNotInteractableException e) {
			WebElement done = driver.findElement(By.xpath("//span[text()='Done']/parent::button"));
			driver.executeScript("arguments[0].click()", done);
		}

		//Schedule Meeting Event:Click on the widget for a new event./Click on "View Calendar".
       try {
		driver.findElement(By.xpath("(//span[@value='NewEvent'])[2]/following::button[@title='More Actions']")).click();
	} catch (Exception e) {
		WebElement newEvent = driver.findElement(By.xpath("(//span[@value='NewEvent'])[2]/following::button[@title='More Actions']"));
		driver.executeScript("arguments[0].click()", newEvent);
	}
       try {
		driver.findElement(By.xpath("//span[text()='View Calendar']")).click();
	} catch (Exception e) {
		WebElement viewCalendar = driver.findElement(By.xpath("//span[text()='View Calendar']"));
		driver.executeScript("arguments[0].click()", viewCalendar);
	}
       
       //Create a new event with the subject as "Meeting"
       Set<String> windows = driver.getWindowHandles();
       List<String> windowsList=new ArrayList<String>(windows);
       driver.switchTo().window(windowsList.get(1));
       String title = driver.getTitle();
       System.out.println("Title of page: "+title);  
       wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'new-event-button')]")));
       driver.findElement(By.xpath("//button[contains(@class,'new-event-button')]")).click();
       driver.findElement(By.xpath("//label[text()='Subject']/following-sibling::div")).click();
       driver.findElement(By.xpath("//span[@title='Meeting']")).click();
       
      // Set the start date as after tomorrow.
       try {
		driver.findElement(By.xpath("//label[text()='Date']/following::button")).click();
	} catch (Exception e) {
		WebElement dateButton = driver.findElement(By.xpath("//label[text()='Date']/following::button"));
		driver.executeScript("arguments[0].click()", dateButton);
	}
       LocalDate dayAfterTom=currentDate.plusDays(2);
       System.out.println("Day after tomo is: "+dayAfterTom);
       DateTimeFormatter format1=DateTimeFormatter.ofPattern("dd-MMM-yyyy");		
       String dayAfterTomformatted = dayAfterTom.format(format1);      
       System.out.println("Formatted date: "+dayAfterTomformatted);
       WebElement startDate = driver.findElement(By.xpath("//legend[text()='Start']/following::input"));
       startDate.clear();
       startDate.sendKeys(dayAfterTomformatted,Keys.ENTER);
       WebElement endDate = driver.findElement(By.xpath("//legend[text()='End']/following::input"));
       endDate.clear();
       endDate.sendKeys(dayAfterTomformatted,Keys.ENTER);
       
       //Enter the description for the meeting.
       obj.scrollToElement(driver.findElement(By.xpath("//span[text()='Description']"))).perform();
       driver.findElement(By.xpath("//span[text()='Description']/following::textarea")).sendKeys("Discussion about the product"+Keys.ENTER);

       //Save the event.
      driver.findElement(By.xpath("//button[@title='Save']")).click();
       //Close the calendar.
       driver.close();
  
       
      
		
		

	}

}



