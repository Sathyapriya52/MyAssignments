package testcasesCrossBrowser;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BaseClass {
	
	
	public static String lastName;
	public static String companyName;
	public WebDriverWait wait;
	public RemoteWebDriver driver;
	
@Parameters({"browser","url","userName","password"})	
@BeforeMethod
	public void preCondtion(String browser,String url,String username,String password) {
		//Turn off notification
	            if(browser.equalsIgnoreCase("chrome")) {
	            	ChromeOptions options=new ChromeOptions();
					options.addArguments("--disable-notifications");
					//Launch the browser
					driver=new ChromeDriver(options);
	           } else if(browser.equalsIgnoreCase("edge")) {
	        	   EdgeOptions options=new EdgeOptions();
					options.addArguments("--disable-notifications");
					//Launch the browser
					driver=new EdgeDriver(options);
	           }
				
				//Load the URL
				driver.get(url);
				//Maximize the window
				driver.manage().window().maximize();
				// Add  implicitlyWait
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				//Login to the application
				driver.findElement(By.id("username")).sendKeys(username);
				driver.findElement(By.id("password")).sendKeys(password);
				driver.findElement(By.id("Login")).click();				
	}
@AfterMethod
public void postCondition() {
	driver.close();
}

}
