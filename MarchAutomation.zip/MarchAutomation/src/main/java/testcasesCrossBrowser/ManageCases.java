package testcasesCrossBrowser;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class ManageCases extends BaseClass {

@Test
	public  void cases() throws IOException {
		

		//Navigate to Sales: Click on the toggle menu button, select 'View All', and click on 'Sales' from the App Launcher.
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();		
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			
		} catch (StaleElementReferenceException e2) {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		try {
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (ElementNotInteractableException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}

		//Access Accounts: Navigate to the 'Accounts' tab.
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Accounts']")));
			driver.findElement(By.xpath("//span[text()='Accounts']")).click();
		} catch (Exception e) {
			WebElement account = driver.findElement(By.xpath("//span[text()='Accounts']"));
			driver.executeScript("arguments[0].click()", account);
		}

		//Open Existing Account: Search for existing accounts and open the desired account.
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Account-search-input']")));
		WebElement search = driver.findElement(By.xpath("//input[@name='Account-search-input']"));		
		search.sendKeys("TCS"+ Keys.ENTER);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-refid='recordId']")));
		try {
			driver.findElement(By.xpath("//a[@data-refid='recordId']")).click();
		} catch (StaleElementReferenceException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-refid='recordId']")));
			driver.findElement(By.xpath("//a[@data-refid='recordId']")).click();
		} catch(ElementClickInterceptedException e) {
			WebElement searchResult = driver.findElement(By.xpath("//a[@data-refid='recordId']"));
			driver.executeScript("arguments[0].click()", searchResult);			
		} catch(ElementNotInteractableException e) {
			WebElement searchResult = driver.findElement(By.xpath("//a[@data-refid='recordId']"));
			driver.executeScript("arguments[0].click()", searchResult);			
		}

		//Create New Case: Click on 'New Cases'.
		driver.findElement(By.xpath("//button[text()='New Case']")).click(); 
		driver.findElement(By.xpath("//input[@title='Search Contacts']")).click();

		//Add New Contact: Click on 'New Contact' in the contact search and create a contact using Java Faker for dynamic data.
		Faker fake=new Faker();
		String lastName = fake.name().lastName();
		driver.findElement(By.xpath("//span[@title='New Contact']")).click(); 
		driver.findElement(By.xpath("//input[contains(@class,'lastName')]")).sendKeys(lastName);
		driver.findElement(By.xpath("(//button[@title='Save']/span)[2]")).click();

		//Save Case: Click 'Save' to save the case.
		try {
			driver.findElement(By.xpath("//footer[@class='slds-modal__footer']//span[text()='Save']")).click();
		} catch (Exception e) {
			WebElement save = driver.findElement(By.xpath("//footer[@class='slds-modal__footer']//span[text()='Save']"));
			driver.executeScript("arguments[0].click()", save);
		}

		//Retrieve Case Number: Retrieve the case number from the toasted message.
		String caseNumber = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]//div")).getText();
		System.out.println("The Case Number is: "+caseNumber);

		//Open and Edit Case: Click on the 'Cases' tab, search and open the case, then click 'Edit'.
		try {
			driver.findElement(By.xpath("//a[@title='Cases']")).click();
		} catch (Exception e) {
			WebElement cases = driver.findElement(By.xpath("//a[@title='Cases']"));
			driver.executeScript("arguments[0].click()", cases);
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Case-search-input']")));
		driver.findElement(By.xpath("//input[@name='Case-search-input']")).sendKeys(caseNumber+Keys.ENTER);
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]")));
			driver.findElement(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]")).click();
		} catch (ElementClickInterceptedException e) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]")));
			WebElement caseNumber1 = driver.findElement(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]"));
			driver.executeScript("arguments[0].click()", caseNumber1);
		} catch (ElementNotInteractableException e) {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]")));
			WebElement caseNumber1 = driver.findElement(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]"));
			driver.executeScript("arguments[0].click()", caseNumber1);
		} 
		catch (StaleElementReferenceException e) {
			driver.get(driver.getCurrentUrl());
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]")));
			driver.findElement(By.xpath("//a[contains(@class,'pLink slds-truncate outputLookupLink-500')]")).click();
		}
			/*} catch (Exception e1) {
				driver.get(driver.getCurrentUrl());
				driver.findElement(By.xpath("//input[@name='Case-search-input']")).sendKeys(caseNumber+Keys.ENTER);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-refid='recordId']")));
				 driver.findElement(By.xpath("//a[@data-refid='recordId']")).click();
			}	*/	

				
		driver.findElement(By.xpath("//button[@name='Edit']")).click();
		
		//Update Case Details: Choose type as 'Others', Case reason as 'Equipment Complexity', case origin as 'Email', and click 'Save'.
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Type']/following::button")));
		driver.findElement(By.xpath("//label[text()='Type']/following::button")).click();
		driver.findElement(By.xpath("//span[@title='Other']")).click();
        driver.findElement(By.xpath("//label[text()='Case Reason']/following::button")).click();
        driver.findElement(By.xpath("//span[@title='Equipment Complexity']")).click();
        driver.findElement(By.xpath("//label[text()='Case Origin']//following::button")).click();
        driver.findElement(By.xpath("//label[text()='Case Origin']//following::button//following::span[@title='Email']")).click();
        driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();           
		
		//Navigate to Related Tab: Click on the 'Related' tab.
        try {
			driver.findElement(By.xpath("//li[@title='Feed']/following-sibling::li[@title='Related']")).click();
		} catch (Exception e1) {
			WebElement related = driver.findElement(By.xpath("//li[@title='Feed']/following-sibling::li[@title='Related']"));
			driver.executeScript("arguments[0].click()", related);
		}

		//Create New Task: Click on 'New Task' for open activities, choose subject as 'Email', set due date as tomorrow, and click 'Save'.
        driver.findElement(By.xpath("//div[@title='New Task']")).click();
        driver.findElement(By.xpath("//label[text()='Subject']/following-sibling::div")).click();
        driver.findElement(By.xpath("//span[@title='Email']/parent::span")).click();
        try {
			driver.findElement(By.xpath("//button[@title='Select a date for Due Date']")).click();
		} catch (Exception e) {
			WebElement date = driver.findElement(By.xpath("//button[@title='Select a date for Due Date']"));
			driver.executeScript("arguments[0].click()", date);
		}
        driver.findElement(By.xpath("//td[@class='slds-is-today']/following-sibling::td")).click();
        driver.findElement(By.xpath("//button[@title='Save']/span")).click();        

		//Printable View: Click on the widget for the cases and select 'Printable View'.
       wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage')]")));
        try {
        	wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[text()='Show more actions']/ancestor::button")));
			driver.findElement(By.xpath("//span[text()='Show more actions']/ancestor::button")).click();
		} catch (TimeoutException e) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("(//span[text()='Show more actions']/ancestor::button)[2]")));
			driver.findElement(By.xpath("(//span[text()='Show more actions']/ancestor::button)[2]")).click();
		}
        catch (ElementClickInterceptedException e) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[text()='Show more actions']/ancestor::button")));
			WebElement printableView = driver.findElement(By.xpath("//span[text()='Show more actions']/ancestor::button"));
			driver.executeScript("arguments[0].click()", printableView);
		} catch (ElementNotInteractableException e) {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[text()='Show more actions']/ancestor::button")));
			WebElement printableView = driver.findElement(By.xpath("//span[text()='Show more actions']/ancestor::button"));
			driver.executeScript("arguments[0].click()", printableView);
		} catch (NoSuchElementException e) {
			driver.get(driver.getCurrentUrl());
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[text()='Show more actions']/ancestor::button")));
			WebElement printableView = driver.findElement(By.xpath("//span[text()='Show more actions']/ancestor::button"));
			driver.executeScript("arguments[0].click()", printableView);
		} 
        System.out.println("Button is clicked");
        try {
        	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Printable View']")));
			driver.findElement(By.xpath("//span[text()='Printable View']")).click();
		} catch (Exception e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Printable View']")));
			WebElement printableView1 = driver.findElement(By.xpath("//span[text()='Printable View']"));
			driver.executeScript("arguments[0].click()", printableView1);
		}

		//Adjust Zoom Level: Set the screen zoom level to 50% and take a snapshot of the page.
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        Set<String> windowHandles = driver.getWindowHandles();
        System.out.println("The size of window:"+windowHandles.size());
        List<String> handlesList=new ArrayList<String>(windowHandles);
        driver.switchTo().window(handlesList.get(1));   
        String title2 = driver.getTitle();
		System.out.println("Title of page2:"+title2);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Close Window']")));        
        driver.executeScript("document.body.style.zoom='50%'");
        File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
        File destination=new File("./snapshot/zoom.jpg");
        FileUtils.copyFile(screenshotAs, destination);

		//Close Window: Click on 'Close Window'.
         try {
			driver.findElement(By.xpath("//a[text()='Close Window']")).click();
		} catch (Exception e) {
			WebElement closeWindow = driver.findElement(By.xpath("//a[text()='Close Window']"));
			driver.executeScript("arguments[0].click()", closeWindow);
		}
         driver.switchTo().window(handlesList.get(0));   
         String title1 = driver.getTitle();
 		System.out.println("Title of page1:"+title1);
	}

}
