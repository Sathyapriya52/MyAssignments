package testcases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseClass {
	public ChromeDriver driver;
	public static String lastName;
	public static String companyName;
	public WebDriverWait wait;
@BeforeMethod
	public void preCondtion() {
		//Turn off notification
				ChromeOptions options=new ChromeOptions();
				options.addArguments("--disable-notifications");
				//Launch the browser
				driver=new ChromeDriver(options);
				//Load the URL
				driver.get("https://login.salesforce.com");
				//Maximize the window
				driver.manage().window().maximize();
				// Add  implicitlyWait
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				//Login to the application
				driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
				driver.findElement(By.id("password")).sendKeys("Testleaf@123");
				driver.findElement(By.id("Login")).click();

				//Click on the toggle menu button
				driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

				//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
				wait=new WebDriverWait(driver, Duration.ofSeconds(30));
				try {
					driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
				} catch (NoSuchElementException e2) {
					driver.get(driver.getCurrentUrl());
					driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
					driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
				} catch (StaleElementReferenceException e2) {
					driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
				}
				try {
					driver.findElement(By.xpath("//p[text()='Sales']")).click();
				} catch (ElementClickInterceptedException e) {
					WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
					driver.executeScript("arguments[0].click()", sales);			
				}catch (ElementNotInteractableException e) {
					WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
					driver.executeScript("arguments[0].click()", sales);			
				}catch (NoSuchElementException e1) {
					driver.get(driver.getCurrentUrl());
					driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
					WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
					viewAll.click();
					driver.findElement(By.xpath("//p[text()='Sales']")).click();
				}
				//Open Leads: Navigate to the 'Leads' tab.
				WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
				//Here using the executeScript method to overcome javascriptException
				driver.executeScript("arguments[0].click()", leadsTab);

	}
@AfterMethod
public void postCondition() {
	driver.close();
}

}
