package testcases;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Step2UpdateLead extends BaseClass {
	@Test(dependsOnMethods={"testcases.Step1LeadCreation.leadCreation"})
	public void updateLead()  {


		//Search for Lead: Perform a search for the lead with the last name .		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Lead-search-input']")));		
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+Keys.ENTER);		

		//Edit Lead: Click on the dropdown icon next to the search result and select 'Edit'.
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Show Actions'])[1]")));
		try {
			driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]")).click();
		} catch (StaleElementReferenceException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Show Actions'])[1]")));			
			try {
				driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]")).click();				
			} catch (ElementClickInterceptedException e1) {
				WebElement dropDown = driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]"));
				driver.executeScript("arguments[0].click()", dropDown);
			}
		}catch (ElementClickInterceptedException e) {
			WebElement dropDown = driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]"));
			driver.executeScript("arguments[0].click()", dropDown);
		}catch (ElementNotInteractableException e) {
			WebElement dropDown = driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]"));
			driver.executeScript("arguments[0].click()", dropDown);
		}
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Edit']")));
		try {
			driver.findElement(By.xpath("//div[text()='Edit']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement edit = driver.findElement(By.xpath("//div[text()='Edit']"));
			driver.executeScript("arguments[0].click()", edit);
		}catch (ElementNotInteractableException e) {
			WebElement edit = driver.findElement(By.xpath("//div[text()='Edit']"));
			driver.executeScript("arguments[0].click()", edit);
		}

		//Update Information: Change the First Name to 'Ganesh'.
		driver.findElement(By.xpath("//input[@name=\"firstName\"]")).clear();
		driver.findElement(By.xpath("//input[@name=\"firstName\"]")).sendKeys("Ganesh");

		//Modify Lead Status: Set the Lead Status to 'Working-Contacted'.		
	
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(@aria-label,'Lead Status')]")));
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(@aria-label,'Lead Status')]")));
			driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status')]")).click();
		} catch (ElementClickInterceptedException e1) {
			WebElement status = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status')]"));
			driver.executeScript("arguments[0].click()", status);
		}catch (ElementNotInteractableException e1) {
			WebElement status = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status')]"));
			driver.executeScript("arguments[0].click()", status);
		}	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Working - Contacted']")));
		try {
			driver.findElement(By.xpath("//span[@title='Working - Contacted']")).click();
		} catch (ElementClickInterceptedException e1) {
			WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
			driver.executeScript("arguments[0].click()", status1);
		}catch (ElementNotInteractableException e1) {
			WebElement status1 = driver.findElement(By.xpath("//span[@title='Working - Contacted']"));		
			driver.executeScript("arguments[0].click()", status1);
		}

		//Save Changes: Click 'Save'.		
		try {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			save.click();
		} catch (ElementClickInterceptedException e) {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save);
		}catch (ElementNotInteractableException e) {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save);
		}		

		//Verification: Confirm that the lead's name is updated as 'Ganesh Kumar'.
		String verificationMessage = driver.findElement(By.xpath("//span[contains(@class,'toastMessage sld')]")).getText();
		System.out.println(verificationMessage);
		if(verificationMessage.contains("Ganesh "+lastName)) {
			System.out.println("Lead name is correctly updated and displayed");
		}
		else {
			System.out.println("Lead name is not correctly updated and displayed");
		}
	}

}
