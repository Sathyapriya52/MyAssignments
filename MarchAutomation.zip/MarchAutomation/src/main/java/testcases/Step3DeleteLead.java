package testcases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Step3DeleteLead extends BaseClass {
	@Test(dependsOnMethods={"testcases.Step2UpdateLead.updateLead"})
	public  void deletedLead() {
				

		//Search for Lead: Perform a search for the lead with the last name.
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Lead-search-input']")));
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(lastName+Keys.ENTER);	

		//Delete Lead: Click on the dropdown icon next to the search result and select 'Delete'.
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Show Actions'])[1]")));
		try {
			driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]")).click();
		} catch (StaleElementReferenceException e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Show Actions'])[1]")));			
			try {
				driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]")).click();				
			} catch (ElementClickInterceptedException e1) {
				WebElement dropDown = driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]"));
				driver.executeScript("arguments[0].click()", dropDown);
			}
		}catch (ElementClickInterceptedException e) {
			WebElement dropDown = driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]"));
			driver.executeScript("arguments[0].click()", dropDown);
		}catch (ElementNotInteractableException e) {
			WebElement dropDown = driver.findElement(By.xpath("(//span[text()='Show Actions'])[1]"));
			driver.executeScript("arguments[0].click()", dropDown);
		}
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Delete']")));
		try {
			driver.findElement(By.xpath("//div[text()='Delete']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement delete = driver.findElement(By.xpath("//div[text()='Delete']"));
			driver.executeScript("arguments[0].click()", delete);
		}catch (ElementNotInteractableException e) {
			WebElement delete = driver.findElement(By.xpath("//div[text()='Delete']"));
			driver.executeScript("arguments[0].click()", delete);
		}
		//Confirm the deletion and verify the lead is successfully deleted or not.
		try {
			driver.findElement(By.xpath("//span[text()='Delete']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement delete = driver.findElement(By.xpath("//span[text()='Delete']"));
			driver.executeScript("arguments[0].click()", delete);
		} catch (ElementNotInteractableException e) {
			WebElement delete = driver.findElement(By.xpath("//span[text()='Delete']"));
			driver.executeScript("arguments[0].click()", delete);
		}

		String toasterMessage = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
		if(toasterMessage.contains(" was deleted.")){
			System.out.println("Lead was deleted Successfully");
		}					
		else{
			System.out.println("Lead was not deleted");
		}
	
	}

}
