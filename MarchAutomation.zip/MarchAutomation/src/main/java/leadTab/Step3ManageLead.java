package leadTab;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Step3ManageLead {

	public static void main(String[] args) throws InterruptedException {
		//Turn off notification
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		//Launch the browser
		ChromeDriver driver=new ChromeDriver(option);
		//Load the URL
		driver.get("https://login.salesforce.com");
		//Maximize the window
		driver.manage().window().maximize();
		// Add  implicitlyWait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//Login to the application
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();
		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();			
		}catch (StaleElementReferenceException e2) {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();			
		}
		try {			
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}
		catch (ElementNotInteractableException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);
		}catch (org.openqa.selenium.NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			try {
				viewAll.click();
			} catch (StaleElementReferenceException e) {
				driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
				WebElement viewAll1 = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
				viewAll1.click();
			}
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}
		//Open Leads: Navigate to the 'Leads' tab.		
		try {
			WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
			leadsTab.click();
		} catch (ElementClickInterceptedException e1) {
			WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
			driver.executeScript("arguments[0].click()", leadsTab);
		}catch (ElementNotInteractableException e1) {
			WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
			driver.executeScript("arguments[0].click()", leadsTab);
		}catch (JavascriptException e1) {
			WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
			driver.executeScript("arguments[0].click()", leadsTab);
		}
		
		//Create New Lead: Click on the 'New' button.
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='New']")));
			driver.findElement(By.xpath("//div[text()='New']")).click();			
		} catch (ElementClickInterceptedException e) {			
			WebElement newButton = driver.findElement(By.xpath("//div[text()='New']"));
			driver.executeScript("arguments[0].click()", newButton);
		}catch (ElementNotInteractableException e) {			
			WebElement newButton = driver.findElement(By.xpath("//div[text()='New']"));
			driver.executeScript("arguments[0].click()", newButton);
		}
		//Set Details: Select Salutation ('Mr' or 'Ms'), input Last Name as 'Any Name', 
		//Company Name as 'Any Company name', and Title as 'QA'.
		driver.findElement(By.xpath("(//div[@class='slds-combobox_container'])[2]")).click();
		driver.findElement(By.xpath("//span[@title='Ms.']")).click();
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("Vijay");
		driver.findElement(By.xpath("//input[@name='Company']")).sendKeys("TCS");
		driver.findElement(By.xpath("//input[@name='Title']")).sendKeys("QA");
		//Save Lead: Click 'Save'.
		driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
		//Verify Lead Name: Confirm that the lead name is displayed as 'Salutation + Last Name' (e.g., 'Mr. Any Name').
		String leadName = driver.findElement(By.xpath("//slot[@name='primaryField']/lightning-formatted-name")).getText();
		System.out.println("leadname="+leadName);
		if(leadName.contains("Ms. Vijay")) {
			System.out.println("Lead name is correctly saved and displayed");
		}			
		else{
			System.out.println("Lead name is not correctly saved and displayed");
		}
		//Verify Details: Confirm that the Title ('QA') and Company details are accurate.
		String title = driver.findElement(By.xpath("(//p[contains(@class,'fieldComponent slds-text-body')]//lightning-formatted-text)[1]")).getText();
		System.out.println("Title is="+title);
		if(title.contains("QA")){
			System.out.println("Title is correctly saved and displayed");
		}else {
			System.out.println("Title is not correctly saved and displayed");
		}
		String company = driver.findElement(By.xpath("(//p[contains(@class,'fieldComponent slds-text-body')]//lightning-formatted-text)[2]")).getText();
		System.out.println("Company is="+company);
		if(company.contains("TCS")) {
			System.out.println("Company name is correctly saved and displayed");
		}			
		else{
			System.out.println("Company name is not correctly saved and displayed");
		}
		//Add Email to To-Do List: Click on the email widget, choose subject as 'Email', set due date as 'Tomorrow date', and click 'Save'.
		WebElement emailWidget = driver.findElement(By.xpath("(//span[text()='More Actions'])[3]"));
		driver.executeScript("arguments[0].click()", emailWidget);
		driver.findElement(By.xpath("//span[text()='Add Email to To Do List']")).click();
		driver.findElement(By.xpath("(//label[text()='Subject']/following::div)[1]")).click();
		driver.findElement(By.xpath("(//span[text()='Email']/parent::span)[2]")).click();
		WebElement date = driver.findElement(By.xpath("//label[text()='Due Date']"));
		wait.until(ExpectedConditions.visibilityOf(date));
		driver.executeScript("arguments[0].click()", date);
		WebElement todayDate = driver.findElement(By.xpath("(//td[@class='slds-is-today']/following-sibling::td)[1]"));
		wait.until(ExpectedConditions.visibilityOf(todayDate));
		todayDate.click();
		driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
		//Send Email: Click on the 'Email' under the 'Activity' tab, enter recipient email ('LastName@companyName.com'), 
		//set subject, compose the email, and click 'Send'.
		WebElement email = driver.findElement(By.xpath("//span[@value='SendEmail']"));
		driver.executeScript("arguments[0].click()", email);
		WebElement recipient = driver.findElement(By.xpath("(//input[@aria-describedby='recipientsInputLabel'])[1]"));
		wait.until(ExpectedConditions.visibilityOf(recipient));
		recipient.sendKeys("vijay@tcs.com");
		driver.findElement(By.xpath("//input[@placeholder='Enter Subject...']")).sendKeys("New Lead");
		//Switch to parent frame
		WebElement iframe = driver.findElement(By.xpath("//iframe[@title='CK Editor Container']"));
		driver.switchTo().frame(iframe);
		//Switch to child frame
		WebElement iframe1 = driver.findElement(By.xpath("//iframe[@title='Email Body']"));
		driver.switchTo().frame(iframe1);
		driver.findElement(By.xpath("//body[@contenteditable='true']")).clear();
		driver.findElement(By.xpath("//body[@contenteditable='true']")).sendKeys("This email is a test email");
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[text()='Send']")).click();
		
		//Check Email Status: Click on the 'Email' widget under 'Upcoming & Overdue', click 'Change Status', 
		//change status to 'Completed', and save.		
		try {
			WebElement action = driver.findElement(By.xpath("(//span[text()='Show more actions'])[3]"));
			action.click();
		} catch (Exception e1) {
			WebElement action = driver.findElement(By.xpath("(//span[text()='Show more actions'])[3]"));
			driver.executeScript("arguments[0].click()", action);
		}
		
		driver.findElement(By.xpath("(//a[@title='Change Status'])[2]")).click();
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='select']/parent::div")));
			driver.findElement(By.xpath("//a[@class='select']/parent::div")).click();				
		} catch (StaleElementReferenceException e) {
			driver.navigate().refresh();
			WebElement select = driver.findElement(By.xpath("//a[@class='select']/parent::div"));
			select.click();			
		} catch(ElementClickInterceptedException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']/parent::div"));
			driver.executeScript("arguments[0].click()", select);
		}catch(ElementNotInteractableException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']/parent::div"));
			driver.executeScript("arguments[0].click()", select);
		}
		driver.findElement(By.xpath("//a[@title='Completed']")).click();
		driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
		driver.close();

	}



}
