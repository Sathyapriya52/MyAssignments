package leadTab;

import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;

public class Step9ReportCreation {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(option);
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		//Login: Log in to the Salesforce account at https://login.salesforce.com.
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();
		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));	
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (Exception e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		try {			
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		} catch (NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch(StaleElementReferenceException e) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}

		//Open Reports: Navigate to the 'Reports' tab.
		WebElement reports = driver.findElement(By.xpath("//a[@title='Reports']"));
		driver.executeScript("arguments[0].click()", reports);

		//Create New Folder: Click on 'New Folder', enter the folder name as 'Your Name', and provide a unique folder name as 'YourName'.
		driver.findElement(By.xpath("//button[@title='New Folder']")).click();
		Faker fake=new Faker();
		String firstName = fake.name().firstName();
		driver.findElement(By.xpath("//span[text()='Folder Label']/following::input")).sendKeys(firstName);
		driver.findElement(By.xpath("//span[text()='Folder Unique Name']/following::input")).sendKeys(firstName);
		driver.findElement(By.xpath("(//button[@title='Save'])[2]")).click();

		//Navigate to All Folders: Click on 'All Folders'.
		try {
			WebElement allFolder = driver.findElement(By.xpath("//a[@title='All Folders']"));
			allFolder.click();
		} catch (ElementClickInterceptedException e2) {
			WebElement allFolder = driver.findElement(By.xpath("//a[@title='All Folders']"));
			driver.executeScript("arguments[0].click()", allFolder);
		}catch (ElementNotInteractableException e2) {
			WebElement allFolder = driver.findElement(By.xpath("//a[@title='All Folders']"));
			driver.executeScript("arguments[0].click()", allFolder);
		}

		//Open Created Folder: Open the folder created with your name.
		driver.findElement(By.xpath("//input[@placeholder='Search all folders...']")).sendKeys(firstName+Keys.ENTER);	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@aria-label='All Folders']//tbody/tr/th[1]")));
		WebElement folder = driver.findElement(By.xpath("//table[@aria-label='All Folders']//tbody/tr/th[1]"));		
		try {			
			folder.click();
			folder.sendKeys(Keys.ENTER);
		} catch (Exception e1) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@aria-label='All Folders']//tbody/tr/th[1]")));
			WebElement folder1= driver.findElement(By.xpath("//table[@aria-label='All Folders']//tbody/tr/th[1]"));			
			driver.executeScript("arguments[0].click()", folder1);
			folder1.sendKeys(Keys.ENTER);
		}


		//Create New Report: Click on 'New Report'.
		try {
			WebElement report = driver.findElement(By.xpath("(//a[@title='New Report'])[2]"));
			report.click();
		} catch (Exception e) {
			WebElement report = driver.findElement(By.xpath("(//a[@title='New Report'])[2]"));			
			driver.executeScript("arguments[0].click()", report);
		}

		//Select Report Type: Choose 'Opportunities' and select 'Opportunity with Products', then click 'Start Report'.
		WebElement frame1 = driver.findElement(By.xpath("//iframe[@title='Report Builder']"));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[@title='Report Builder']")));
		driver.switchTo().frame(frame1);
		WebElement opp = driver.findElement(By.xpath("//a[text()='Opportunities']"));
		driver.executeScript("arguments[0].click()", opp);
		WebElement pro = driver.findElement(By.xpath("//p[text()='Opportunities with Products']"));
		driver.executeScript("arguments[0].click()", pro);
		WebElement report1 = driver.findElement(By.xpath("//button[text()='Start Report']"));
		driver.executeScript("arguments[0].click()", report1);

		//Save Report: Click 'Save' and provide a meaningful name for the report.
		try {
			WebElement save = driver.findElement(By.xpath("//button[text()='Save']"));
			save.click();
		} catch (Exception e) {
			WebElement save = driver.findElement(By.xpath("//button[text()='Save']"));
			driver.executeScript("arguments[0].click()", save);
		}		
		driver.findElement(By.id("reportName")).sendKeys("List of new opportunities report");
		try {
			WebElement save1 = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			save1.click();
		} catch (Exception e) {
			WebElement save1 = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save1);
		}	
		driver.switchTo().defaultContent();
		
		//Run Report: Click 'Run' to generate the report.
		//WebElement reportBuilder= driver.findElement(By.xpath("//iframe[@title='Report Builder']"));		
		driver.switchTo().frame(frame1);
		try {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frame1));
		} catch (StaleElementReferenceException e1) {
			driver.switchTo().frame(frame1);
		}		
		try {			
			driver.findElement(By.xpath("//button[text()='Run']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement run1 = driver.findElement(By.xpath("//button[text()='Run']"));
			driver.executeScript("arguments[0].click()", run1);
		} catch (ElementNotInteractableException e) {
			WebElement run1 = driver.findElement(By.xpath("//button[text()='Run']"));
			driver.executeScript("arguments[0].click()", run1);
		} catch (NoSuchElementException e) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//a[text()='Opportunities']")).click();
			driver.findElement(By.xpath("//p[text()='Opportunities with Products']")).click();
			driver.findElement(By.xpath("//button[text()='Start Report']")).click();
			driver.findElement(By.xpath("//button[text()='Save']")).click();
			driver.switchTo().defaultContent();
			driver.switchTo().frame(frame1);	
						driver.findElement(By.xpath("//button[text()='Run']")).click();
		} catch (StaleElementReferenceException e) {
			driver.findElement(By.xpath("//button[text()='Run']")).click();
		}
		driver.switchTo().defaultContent();
		System.out.println("moved ");

		//Verify Report Creation: Confirm that the report is successfully created.
		
		try {
			WebElement reportFrame = driver.findElement(By.xpath("//iframe[@title='Report Viewer']"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[@title='Report Viewer']")));
			driver.switchTo().frame(reportFrame);
		} catch (NoSuchElementException e) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//button[text()='Run']")).click();
			WebElement reportFrame = driver.findElement(By.xpath("//iframe[@title='Report Viewer']"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[@title='Report Viewer']")));
			driver.switchTo().frame(reportFrame);
		}		
		System.out.println("Moved1");
		String title = driver.findElement(By.xpath("//div[@class='slds-page-header__name-title']")).getText();
		System.out.println(title);
		if(title.contains("List of new opportunities report")) {
			System.out.println("The report is successfully created");
		}else {
			System.out.println("The report is not created");
		}
		driver.switchTo().defaultContent();
		driver.close();
	}

}
