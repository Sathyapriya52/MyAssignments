package leadTab;

import java.io.File;
import java.io.IOException;
import java.time.Duration;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Step5ConvertLead {

	public static void main(String[] args) throws InterruptedException, IOException {
		//Disable notification
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(option);		
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//Login: Log in to the Salesforce account at 
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();

		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));		
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			try {
				driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			} catch (StaleElementReferenceException e) {
				driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			}
		} catch (StaleElementReferenceException e2) {			
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		try {
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		} catch (ElementNotInteractableException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		} 
		catch (NoSuchElementException e) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}

		//Open Leads: Navigate to the 'Leads' tab.
		WebElement leads = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
		driver.executeScript("arguments[0].click()", leads);

		//Search and Open Lead: Search for an existing lead and open it.
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@name='Lead-search-input']")));
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys("Vijay"+ Keys.ENTER);			
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@data-refid='recordId']")));
				
		try {
			WebElement leadName = driver.findElement(By.xpath("//a[@data-refid='recordId']"));	
			leadName.click();
		} catch (StaleElementReferenceException e2) {
			driver.findElement(By.xpath("//a[@data-refid='recordId']")).click();
		} catch (ElementClickInterceptedException e2) {
			WebElement leadName = driver.findElement(By.xpath("//a[@data-refid='recordId']"));
			driver.executeScript("arguments[0].click()", leadName);
		} catch (ElementNotInteractableException e2) {
			WebElement leadName = driver.findElement(By.xpath("//a[@data-refid='recordId']"));
			driver.executeScript("arguments[0].click()", leadName);
		}			

		//Edit Lead Status: Click on the 'Details' tab, locate the lead status, 
		//click the edit icon, and change the lead status to 'Working - Contacted'.

		WebElement details = driver.findElement(By.xpath("//li[@title='Details']"));
		wait.until(ExpectedConditions.visibilityOf(details));
		details.click();
		//driver.findElement(By.xpath("(//span[text()='Lead Status'])[2]")).click();
		WebElement edit = driver.findElement(By.xpath("//span[text()='Edit Lead Status']"));
		driver.executeScript("arguments[0].click()", edit);
		WebElement dropDown = driver.findElement(By.xpath("//label[text()='Lead Status']"));
		Actions obj=new Actions(driver);
		obj.scrollToElement(dropDown).perform();

		try {
			driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
		} catch (ElementNotInteractableException e) {
			WebElement leadStatus = driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]"));
			driver.executeScript("arguments[0].click()", leadStatus);
		}		
			
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Working - Contacted'])[2]")));
			WebElement status = driver.findElement(By.xpath("(//span[text()='Working - Contacted'])[2]"));		
			status.click();
		} /*catch (NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@title='Details']")));
			driver.findElement(By.xpath("//li[@title='Details']")).click();			
			//driver.findElement(By.xpath("//span[text()='Lead Status']")).click();
			WebElement edit1 = driver.findElement(By.xpath("//span[text()='Edit Lead Status']"));
			driver.executeScript("arguments[0].click()", edit1);			
			WebElement dropDown1 = driver.findElement(By.xpath("//label[text()='Lead Status']"));
			Actions obj1=new Actions(driver);
			obj1.scrollToElement(dropDown1).perform();
			driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status')]")).click();
			driver.findElement(By.xpath("//button[contains(@aria-label,'Lead Status - Current Selection')]")).click();
			driver.findElement(By.xpath("//span[text()='Working - Contacted']/parent::span)")).click();
			
		}*/
		catch (ElementClickInterceptedException e1) {
			WebElement status1 = driver.findElement(By.xpath("(//span[text()='Working - Contacted'])[2]"));	
			driver.executeScript("arguments[0].click()", status1);
		} catch (ElementNotInteractableException e1) {
			WebElement status1 = driver.findElement(By.xpath("(//span[text()='Working - Contacted'])[2]"));	
			driver.executeScript("arguments[0].click()", status1);
		}		

		//Save Changes: Click 'Save'.
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();

		//Check Status Completion: If the lead status 'Working - Contacted' is not marked as completed, click on 'Mark Status as Complete'.
		String text = driver.findElement(By.xpath("(//a[@title='Open - Not Contacted']//span)[3]")).getText();
		System.out.println(text);
		String stageStatus = driver.findElement(By.xpath("//a[@title='Working - Contacted']/span")).getText();
		System.out.println(stageStatus);
		if(stageStatus.contains("stage complete")) {
			System.out.println("Working - Contacted stage is marked as completed");
		}else {
			WebElement markStatus = driver.findElement(By.xpath("//span[text()='Mark Status as Complete']"));
			driver.executeScript("arguments[0].click()", markStatus);
		}
		String stageStatus1 = driver.findElement(By.xpath("//a[@title='Working - Contacted']")).getText();
		System.out.println(stageStatus1);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(@class,'toastMessage sld')]")));
		//Convert Lead: Click on the widget near 'Submit for Approval', then click 'Convert'.
		try {
			driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		} catch (ElementNotInteractableException e) {
			WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
			driver.executeScript("arguments[0].click()", showMore);
		}
		
		try {
			driver.findElement(By.xpath("//span[text()='Convert']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement dropDown2 = driver.findElement(By.xpath("//span[text()='Convert']"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (ElementNotInteractableException e) {
			WebElement dropDown2 = driver.findElement(By.xpath("//span[text()='Convert']"));
			driver.executeScript("arguments[0].click()", dropDown2);
		} catch (StaleElementReferenceException e) {
			driver.get(driver.getCurrentUrl());
			try {
				driver.findElement(By.xpath("//span[text()='Convert']")).click();
			} catch (ElementClickInterceptedException e1) {
				WebElement dropDown2 = driver.findElement(By.xpath("//span[text()='Convert']"));
				driver.executeScript("arguments[0].click()", dropDown2);
			}
		}

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
			driver.findElement(By.xpath("//button[text()='Convert']")).click();			
		} catch (Exception e) {
			WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
			driver.executeScript("arguments[0].click()", convert1);
		}

		//Snapshot: Take a screenshot of the pop-up window.
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Your lead has been converted']")));
		} catch (Exception e) {
			driver.get(driver.getCurrentUrl());
			try {
				driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button")).click();
			} catch (ElementClickInterceptedException e1) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			} catch (ElementNotInteractableException e1) {
				WebElement showMore = driver.findElement(By.xpath("//span[text()='Show more actions']/parent::button"));
				driver.executeScript("arguments[0].click()", showMore);
			}
			
			try {
				driver.findElement(By.xpath("//span[text()='Convert']")).click();
			} catch (ElementClickInterceptedException e1) {
				WebElement dropDown2 = driver.findElement(By.xpath("//span[text()='Convert']"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} catch (ElementNotInteractableException e1) {
				WebElement dropDown2 = driver.findElement(By.xpath("//span[text()='Convert']"));
				driver.executeScript("arguments[0].click()", dropDown2);
			} catch (StaleElementReferenceException e1) {
				driver.get(driver.getCurrentUrl());
				try {
					driver.findElement(By.xpath("//span[text()='Convert']")).click();
				} catch (ElementClickInterceptedException e2) {
					WebElement dropDown2 = driver.findElement(By.xpath("//span[text()='Convert']"));
					driver.executeScript("arguments[0].click()", dropDown2);
				}
			}
			try {
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Convert']")));
				driver.findElement(By.xpath("//button[text()='Convert']")).click();			
			} catch (Exception e1) {
				WebElement convert1 = driver.findElement(By.xpath("//button[text()='Convert']"));
				driver.executeScript("arguments[0].click()", convert1);
			}
			
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Your lead has been converted']")));
		WebElement elementToSnap = driver.findElement(By.xpath("//div[contains(@class,'modal-body')]"));		
		File screenshotAs=elementToSnap.getScreenshotAs(OutputType.FILE);
		File destination1=new File("./snapshot/002.png");
		FileUtils.copyFile(screenshotAs, destination1);
		System.out.println("captured");

		//Close Pop-up: Close the pop-up window.
		WebElement close = driver.findElement(By.xpath("//span[text()='Close this window']"));
		driver.executeScript("arguments[0].click()", close);
		driver.close();


	}

}
