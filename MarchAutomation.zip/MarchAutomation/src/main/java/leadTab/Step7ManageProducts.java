package leadTab;

import java.time.Duration;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Step7ManageProducts {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(option);
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//Login: Log in to the Salesforce account at https://login.salesforce.com.
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();

		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));

		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (Exception e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}

		try {
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (NoSuchElementException e1) {
			driver.navigate().refresh();
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}
		//Open Leads: Navigate to the 'opportunity' tab.
		WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
		driver.executeScript("arguments[0].click()", opp);

		//Search and Open opportunity: Search for an existing opportunity and open it.
		driver.findElement(By.xpath("//input[@name='Opportunity-search-input']")).sendKeys("TCS"+Keys.ENTER);		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@name='Opportunity-search-input']")));
		try {
			driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]")).click();
		} catch (StaleElementReferenceException e1) {			
			driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]")).click();
		}catch (ElementClickInterceptedException e1) {			
			WebElement record = driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]"));
			driver.executeScript("arguments[0].click()", record);
		}catch (ElementNotInteractableException e1) {			
			WebElement record = driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]"));
			driver.executeScript("arguments[0].click()", record);
		}

		//Check Qualification Stage: Ensure that the qualification stage is marked as completed. If not, click 'Mark Stage as Complete'.
		//WebElement stage = driver.findElement(By.xpath("//span[text()='Mark Stage as Complete']"));
		//	driver.executeScript("arguments[0].click()", stage);
		//Select Price Book: Click on the widget for the product under 'Related', choose 'Choose Price Book', select 'Standard', and click 'Save'.
		WebElement showProduct = driver.findElement(By.xpath("//span[text()='Show actions for Products']"));
		driver.executeScript("arguments[0].click()", showProduct);
		driver.findElement(By.xpath("//a[@title='Choose Price Book']")).click();
		driver.findElement(By.xpath("//a[@class='select']")).click();

		WebElement priceBook = driver.findElement(By.xpath("//a[text()='Standard']"));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a[text()='Standard']")));
		try {
			priceBook.click();
		} catch (ElementClickInterceptedException e) {
			driver.executeScript("arguments[0].click()", priceBook);
		}catch (ElementNotInteractableException e) {
			driver.executeScript("arguments[0].click()", priceBook);
		}
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();

		//Add Products: Click on the widget for the product under 'Related', click 'Add Products'.

		try {
			WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a")));
			showProduct1.click();
		} catch (ElementClickInterceptedException e) {
			WebElement showProduct1 = driver.findElement(By.xpath("//li[@data-aura-class='oneActionsDropDown']//a"));
			driver.executeScript("arguments[0].click()", showProduct1);	
		}
		driver.findElement(By.xpath("//a[@title='Add Products']")).click();

		//Search and Display Products: Search for "SLA" in the products search field, display and print all the product names for the search results.
		WebElement sla = driver.findElement(By.xpath("//input[@title='Search Products']"));
		sla.click();
		sla.sendKeys("SLA"+Keys.ENTER);

		try {
			//driver.findElement(By.xpath("(//div[@data-aura-class='forceSearchInputLookupDesktopActionItem'])[1]")).click();
			driver.findElement(By.xpath("//span[text()='Search Products']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
			driver.executeScript("arguments[0].click()", sla1);
		}catch (ElementNotInteractableException e) {
			WebElement sla1 = driver.findElement(By.xpath("//span[text()='Search Products']"));
			driver.executeScript("arguments[0].click()", sla1);
		}
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]")));
		WebElement table = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]"));	
		List<WebElement> row = table.findElements(By.tagName("tr"));
		System.out.println("Row count: "+row.size());
		System.out.println("The product name:");
		for(int i=1;i<row.size();i++) {
			String productName = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr["+i+"]/th[1]")).getText();
			System.out.println(productName);
		}

		//Select Products: Click on 'Select All' checkbox, click 'Next', and enter the quantities for 
		//each product type (Platinum - 1, Gold - 2, Silver - 5, Bronze - 10).
		WebElement select = driver.findElement(By.xpath("//span[text()='Select 4 items']"));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Select 4 items']")));
		try {
			select.click();
		} catch (ElementClickInterceptedException e) {
			driver.executeScript("arguments[0].click()", select);
		}
		driver.findElement(By.xpath("//span[text()='Next']")).click();		
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]")).click();
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]")));
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]//input")).sendKeys("2"+Keys.ENTER);
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr[2]/td[2]")).click();
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr[2]/td[2]//input")).sendKeys("10"+Keys.ENTER);
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr[3]/td[2]")).click();
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr[3]/td[2]//input")).sendKeys("1"+Keys.ENTER);
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr[4]/td[2]")).click();
		driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr[4]/td[2]//input")).sendKeys("5"+Keys.ENTER);

		//Save Products: Click 'Save'.

		WebElement save = driver.findElement(By.xpath("(//span[text()='Save'])[2]"));
		wait.until(ExpectedConditions.visibilityOf(save));
		save.click();

		//View All Products: Click on 'View All'.
		WebElement products = driver.findElement(By.xpath("(//span[text()='Products'])[2]"));
		driver.executeScript("arguments[0].click()", products);

		//Retrieve Product Details: For each resulting product, click the widget, 
		//click 'Edit', retrieve the product code along with the product name, and close the window.		
		WebElement table1 = driver.findElement(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]"));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//table[@data-aura-class='uiVirtualDataTable'])[2]/tbody//tr/td[2]")));
		List<WebElement> row1 = table1.findElements(By.tagName("tr"));
		System.out.println("Row count: "+row1.size());
		for(int i=1;i<row1.size()+1;i++) {
			driver.findElement(By.xpath("(//table)[2]/tbody//tr["+i+"]/td[6]")).click();
			//driver.executeScript("arguments[0].click()",click);

			//driver.findElement(By.xpath("//a[@role='menuitem']")).click();
			//driver.findElement(By.xpath("(//div[@class='forceActionLink'])[1]")).click();
			driver.findElement(By.xpath("(//a[@title='Edit'])["+i+"]")).click();
			wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//a[@title='Edit']")));

			String productCode = driver.findElement(By.xpath("//span[text()='Product Code']/following::span")).getText();
			String productName = driver.findElement(By.xpath("(//span[@class='uiOutputText forceOutputLookup'])[2]")).getText();
			System.out.println("The product code is: "+productCode+" and the Product name is: "+productName);
			WebElement close = driver.findElement(By.xpath("//span[text()='Close this window']"));
			driver.executeScript("arguments[0].click()", close);
			driver.close();
		}



	}

}
