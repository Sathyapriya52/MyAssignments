package leadTab;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Step8ManageTaskAndAttachment {

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		ChromeDriver driver=new ChromeDriver(option);
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		//Login: Log in to the Salesforce account at https://login.salesforce.com.
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();
		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (NoSuchElementException e1) {
			driver.navigate().refresh();
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}

		//Open Opportunities: Navigate to the 'Opportunities' tab.
		WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
		driver.executeScript("arguments[0].click()", opp);

		//Search and Open Opportunity: Search for an existing opportunity and open it.
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='Opportunity-search-input']")));
		driver.findElement(By.xpath("//input[@name='Opportunity-search-input']")).sendKeys("TCS"+Keys.ENTER);		
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[@data-refid='recordId'])[1]")));
			driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]")).click();			
		} catch (StaleElementReferenceException e1) {
		  driver.findElement(By.xpath("(//a[@data-refid='recordId'])[1]")).click();
		}

		//Create New Task: Click on the new task icon.
		driver.findElement(By.xpath("(//span[text()='New Task'])[2]")).click();

		//Set Task Details: Choose subject as 'Other', enter due date as either today or tomorrow, and click 'Save'.
		driver.findElement(By.xpath("//label[text()='Subject']/following-sibling::div")).click();
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Other']/parent::span")));
			driver.findElement(By.xpath("//span[@title='Other']/parent::span")).click();			
		} catch (ElementClickInterceptedException e) {
			WebElement subject = driver.findElement(By.xpath("//span[@title='Other']/parent::span"));
			driver.executeScript("arguments[0].click()", subject);
		}catch (ElementNotInteractableException e) {
			WebElement subject = driver.findElement(By.xpath("//span[@title='Other']/parent::span"));
			driver.executeScript("arguments[0].click()", subject);
		}
		try {
			WebElement date = driver.findElement(By.xpath("//button[@title='Select a date for Due Date']"));
			date.click();
		} catch (ElementClickInterceptedException e) {
			WebElement date = driver.findElement(By.xpath("//button[@title='Select a date for Due Date']"));
			driver.executeScript("arguments[0].click()", date);
		}catch (ElementNotInteractableException e) {
			WebElement date = driver.findElement(By.xpath("//button[@title='Select a date for Due Date']"));
			driver.executeScript("arguments[0].click()", date);
		}
		driver.findElement(By.xpath("//td[@class='slds-is-today']")).click();
		driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();

		//Upload Sample File: Under 'Notes and Attachments', upload a sample file.
		WebElement upload = driver.findElement(By.xpath("//input[@type='file']"));
		upload.sendKeys("C:\\Users\\sathy\\OneDrive\\Desktop\\Screenshot 2024-01-20 181042.png");

		try {			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Done']")));
			driver.findElement(By.xpath("//span[text()='Done']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement done = driver.findElement(By.xpath("//span[text()='Done']"));
			driver.executeScript("arguments[0].click()", done);
		}catch (ElementNotInteractableException e) {
			WebElement done = driver.findElement(By.xpath("//span[text()='Done']"));
			driver.executeScript("arguments[0].click()", done);
		}

		//Verify File Name: Confirm that the uploaded file name is displayed under 'Notes and Attachments'.		
		String image = driver.findElement(By.xpath("(//div[@aria-live='polite'])[2]")).getText();
		if(image.contains("Screenshot")) {
			System.out.println("Correct file is uploaded");
		}
		else {
			System.out.println("Incorrect file is uploaded");
		}
		//Navigate to Details: Click on the 'Details' tab.
		try {			
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//a[@data-tab-value='detailTab']")));
			driver.findElement(By.xpath("//a[@data-tab-value='detailTab']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement detail = driver.findElement(By.xpath("//a[@data-tab-value='detailTab']"));
			driver.executeScript("arguments[0].click()", detail);
		}catch (ElementNotInteractableException e) {
			WebElement detail = driver.findElement(By.xpath("//a[@data-tab-value='detailTab']"));
			driver.executeScript("arguments[0].click()", detail);
		}

		//Update Opportunity Stage: Click on the stage icon for the stage dropdown, change the stage to 'Needs Analysis', 
		//and enter the description as "Attachments uploaded successfully."
		WebElement stage = driver.findElement(By.xpath("//span[text()='Edit Stage']"));
		driver.executeScript("arguments[0].click()", stage);
		try {
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("(//label[text()='Stage']/following::button)[1]")));
			driver.findElement(By.xpath("(//label[text()='Stage']/following::button)[1]")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement stage1 = driver.findElement(By.xpath("(//label[text()='Stage']/following::button)[1]"));
			driver.executeScript("arguments[0].click()", stage1);
		}catch (ElementNotInteractableException e) {
			WebElement stage1 = driver.findElement(By.xpath("(//label[text()='Stage']/following::button)[1]"));
			driver.executeScript("arguments[0].click()", stage1);
		}

		try {			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Needs Analysis']")));
			driver.findElement(By.xpath("//span[@title='Needs Analysis']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement analysis = driver.findElement(By.xpath("//span[@title='Needs Analysis']"));
			driver.executeScript("arguments[0].click()", analysis);
		}catch (ElementNotInteractableException e) {
			WebElement analysis = driver.findElement(By.xpath("//span[@title='Needs Analysis']"));
			driver.executeScript("arguments[0].click()", analysis);
		}
		driver.findElement(By.xpath("//textarea[@class='slds-textarea']")).sendKeys("Attachments uploaded successfully");
		try {
			driver.findElement(By.xpath("(//button[text()='Save'])[2]")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save);
		} catch (ElementNotInteractableException e) {
			WebElement save = driver.findElement(By.xpath("(//button[text()='Save'])[2]"));
			driver.executeScript("arguments[0].click()", save);
		}

		//Check Stage Completion: Confirm that 'Needs Analysis' stage is marked as completed. If not, click 'Mark Stage as Complete'.
		String stageStatus = driver.findElement(By.xpath("//a[@title='Needs Analysis']")).getText();
		if(stageStatus.contains("stage complete")) {
			System.out.println("Needs Analysis' stage is marked as completed");
		}else {
			WebElement stage2 = driver.findElement(By.xpath("//span[text()='Mark Stage as Complete']"));
			driver.executeScript("arguments[0].click()", stage2);
		}
		driver.close();
	}

}
