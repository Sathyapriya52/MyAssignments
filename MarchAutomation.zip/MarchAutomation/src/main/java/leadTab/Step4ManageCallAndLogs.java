package leadTab;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Step4ManageCallAndLogs {

	public static void main(String[] args) throws InterruptedException {
		//Turn off the notification
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--disable-notifications");
		//Initialize the driver
		ChromeDriver driver=new ChromeDriver(option);
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		//Login: Log in to the Salesforce account at 
		driver.findElement(By.id("username")).sendKeys("sathyapriya.v@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Testleaf@123");
		driver.findElement(By.id("Login")).click();
		//Click on the toggle menu button
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();

		//Access Sales App: Select 'View All' and click on 'Sales' from the App Launcher.
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		} catch (NoSuchElementException e2) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			try {
				driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			} catch (StaleElementReferenceException e) {
				driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
			}
		} catch (StaleElementReferenceException e2) {
			driver.findElement(By.xpath("//button[@aria-label='View All Applications']")).click();
		}
		try {
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement sales = driver.findElement(By.xpath("//p[text()='Sales']"));
			driver.executeScript("arguments[0].click()", sales);			
		}catch (NoSuchElementException e1) {
			driver.get(driver.getCurrentUrl());
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			WebElement viewAll = driver.findElement(By.xpath("//button[@aria-label='View All Applications']"));
			viewAll.click();
			driver.findElement(By.xpath("//p[text()='Sales']")).click();
		}
		//Open Leads: Navigate to the 'Leads' tab.
		WebElement leadsTab = driver.findElement(By.xpath("(//span[text()='Leads'])[1]"));
		driver.executeScript("arguments[0].click()", leadsTab);

		//Search and Open Lead: Search for an existing lead and open it.
		driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys("Vijay"+Keys.ENTER);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[@name='Lead-search-input']"))));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@data-refid='recordId']/parent::span")));
		WebElement leadName = driver.findElement(By.xpath("//a[@data-refid='recordId']/parent::span"));
		driver.executeScript("arguments[0].click()", leadName);
		

		//Log a Call To-Do: Click on the 'Log a Call' widget, choose subject as 'call', set due date as 'Tomorrow date', and click 'Save'.
		driver.findElement(By.xpath("(//button[@title='More Actions'])[1]")).click();
		driver.findElement(By.xpath("//span[text()='Add Call to To Do List']")).click();
		driver.findElement(By.xpath("//input[@aria-haspopup='listbox']")).click();
		WebElement call = driver.findElement(By.xpath("//span[text()='Call']"));
		driver.executeScript("arguments[0].click()", call);
		WebElement date = driver.findElement(By.xpath("//button[@title='Select a date for Due Date']"));
		driver.executeScript("arguments[0].click()", date);
		try {
			driver.findElement(By.xpath("(//td[@class='slds-is-today']/following-sibling::td)[1]")).click();
		} catch (StaleElementReferenceException e2) {			
			driver.findElement(By.xpath("(//td[@class='slds-is-today']/following-sibling::td)[1]")).click();
		}
		try {
			driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
		} catch (ElementClickInterceptedException e2) {
			WebElement save = driver.findElement(By.xpath("(//span[text()='Save'])[3]"));
			driver.executeScript("arguments[0].click()", save);
		}

		//View Logged Call: Click on 'Log a Call' under the 'Activity' tab, enter comments ('Can we discuss working together?'), and click 'Save'.
		try {
			driver.findElement(By.xpath("//span[@value='LogACall']")).click();
		} catch (ElementClickInterceptedException e1) {
			WebElement logACall = driver.findElement(By.xpath("//span[@value='LogACall']"));
			driver.executeScript("arguments[0].click()", logACall);
		}
		driver.findElement(By.xpath("//textarea[@role='textbox']")).sendKeys("Can we discuss working together?");
		WebElement save = driver.findElement(By.xpath("(//span[text()='Save'])[3]"));
		driver.executeScript("arguments[0].click()", save);

		//Check Call Status: Click on the 'Call' widget under 'Upcoming & Overdue', click 'Change Status', change status to 'Completed', and save
		WebElement action = driver.findElement(By.xpath("(//span[text()='Show more actions'])[3]"));
		wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath("(//span[text()='Show more actions'])[3]"))));
		//wait.until(ExpectedConditions.visibilityOf(action));
		driver.executeScript("arguments[0].click()", action);
		driver.findElement(By.xpath("(//a[@title='Change Status'])[2]")).click();
		try {
			driver.findElement(By.xpath("//a[@class='select']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement select = driver.findElement(By.xpath("//a[@class='select']"));
			driver.executeScript("arguments[0].click()", select);
		}
		try {
			driver.findElement(By.xpath("//a[text()='Completed']")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement completed = driver.findElement(By.xpath("//a[text()='Completed']"));
			driver.executeScript("arguments[0].click()", completed);
		}
		try {
			driver.findElement(By.xpath("(//span[text()='Save'])[3]")).click();
		} catch (ElementClickInterceptedException e) {
			WebElement save1 = driver.findElement(By.xpath("(//span[text()='Save'])[3]"));
			driver.executeScript("arguments[0].click()", save1);
		}catch (ElementNotInteractableException e) {
			WebElement save1 = driver.findElement(By.xpath("(//span[text()='Save'])[3]"));
			driver.executeScript("arguments[0].click()", save1);
		}
		driver.close();
	}

}
